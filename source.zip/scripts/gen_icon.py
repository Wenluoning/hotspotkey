#!/usr/bin/env python3
"""
gen_icon.py — 生成 1024×1024 App 图标（纯标准库，无需 Pillow）

画法：紫蓝渐变底 + 白色 WiFi 三弧。用 SDF（有符号距离场）做抗锯齿，
不依赖任何图像库，iOS 打包时会自己裁圆角。
"""

from __future__ import annotations

import pathlib
import struct
import zlib

SIZE = 1024
OUT = pathlib.Path(__file__).resolve().parent.parent / \
    "HotspotKey" / "Resources" / "Assets.xcassets" / "AppIcon.appiconset" / "AppIcon1024.png"

# 配色
TOP = (0.478, 0.400, 0.960)     # #7A66F5
BOTTOM = (0.212, 0.145, 0.780)  # #3625C7
WHITE = (1.0, 1.0, 1.0)

CX, CY = 512.0, 690.0           # WiFi 圆心
ARC_THICKNESS = 66.0
RADII = (176.0, 322.0, 468.0)
DOT_RADIUS = 62.0
HALF_ANGLE_DEG = 46.0


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def coverage(width: float) -> float:
    """把「像素中心到边界还有多少」换成 0…1 覆盖率"""
    return max(0.0, min(1.0, width * 0.5 + 0.5))


def build_rows() -> bytearray:
    import math

    half_angle = math.radians(HALF_ANGLE_DEG)
    rows = bytearray()
    for y in range(SIZE):
        rows.append(0)  # PNG filter: none
        # 背景渐变（对角）
        for x in range(SIZE):
            t = (x / SIZE * 0.45 + y / SIZE * 0.55)
            r = lerp(TOP[0], BOTTOM[0], t)
            g = lerp(TOP[1], BOTTOM[1], t)
            b = lerp(TOP[2], BOTTOM[2], t)

            # --- 图形部分 ---
            dx = x + 0.5 - CX
            dy = CY - (y + 0.5)           # 向上为正
            dist = math.hypot(dx, dy)
            angle = math.atan2(abs(dx), dy) if dist > 0 else 0.0   # 0 = 正上方

            alpha = 0.0

            # 中心圆点
            alpha = max(alpha, coverage(DOT_RADIUS - dist))

            # 三道弧
            if angle <= half_angle + 0.02:
                angle_fade = coverage((half_angle - angle) * dist)
                for radius in RADII:
                    radial = coverage(ARC_THICKNESS * 0.5 - abs(dist - radius))
                    alpha = max(alpha, radial * angle_fade)

            if alpha > 0:
                r = lerp(r, WHITE[0], alpha)
                g = lerp(g, WHITE[1], alpha)
                b = lerp(b, WHITE[2], alpha)

            rows.append(int(max(0, min(255, r * 255 + 0.5))))
            rows.append(int(max(0, min(255, g * 255 + 0.5))))
            rows.append(int(max(0, min(255, b * 255 + 0.5))))
    return rows


def chunk(tag: bytes, data: bytes) -> bytes:
    return (struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def write_png(path: pathlib.Path, raw: bytearray) -> None:
    header = struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0)  # 8bit RGB
    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", header)
           + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
           + chunk(b"IEND", b""))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def main() -> None:
    raw = build_rows()
    write_png(OUT, raw)
    print(f"written: {OUT}  ({OUT.stat().st_size:,} B, {SIZE}x{SIZE})")


if __name__ == "__main__":
    main()
