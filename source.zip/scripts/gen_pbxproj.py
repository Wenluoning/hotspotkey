#!/usr/bin/env python3
"""
gen_pbxproj.py — 生成 HotspotKey.xcodeproj/project.pbxproj

手写 pbxproj 容易在 UUID / 分组里出错，这里用脚本按固定结构生成，
UUID 由路径 md5 派生，保证唯一、稳定、可重复生成。

用法：python3 scripts/gen_pbxproj.py
"""

from __future__ import annotations

import hashlib
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
PROJ = ROOT / "HotspotKey.xcodeproj" / "project.pbxproj"

APP = "HotspotKey"
BUNDLE_ID = "com.yg.hotspotkey"
DEPLOYMENT_TARGET = "16.0"

# (组名, 组内相对路径, [(文件名, pbxproj 文件类型)])
GROUPS: list[tuple[str, str, list[tuple[str, str]]]] = [
    ("App", "App", [("HotspotKeyApp.swift", "sourcecode.swift")]),
    ("Models", "Models", [("Hotspot.swift", "sourcecode.swift"),
                          ("SeedData.swift", "sourcecode.swift")]),
    ("Services", "Services", [("CryptoBox.swift", "sourcecode.swift"),
                             ("WiFiManager.swift", "sourcecode.swift"),
                             ("HotspotStore.swift", "sourcecode.swift"),
                             ("HotspotAPI.swift", "sourcecode.swift"),
                             ("QRCode.swift", "sourcecode.swift"),
                             ("AutoJoinEngine.swift", "sourcecode.swift"),
                             ("SiteStore.swift", "sourcecode.swift"),
                             ("RegionWatcher.swift", "sourcecode.swift")]),
    ("Views", "Views", [("Components.swift", "sourcecode.swift"),
                        ("RootView.swift", "sourcecode.swift"),
                        ("HomeView.swift", "sourcecode.swift"),
                        ("LibraryView.swift", "sourcecode.swift"),
                        ("HotspotDetailView.swift", "sourcecode.swift"),
                        ("ShareView.swift", "sourcecode.swift"),
                        ("ScannerView.swift", "sourcecode.swift"),
                        ("SettingsView.swift", "sourcecode.swift")]),
    ("Support", "Support", [("Info.plist", "text.plist.xml"),
                            ("HotspotKey.entitlements", "text.plist.entitlements"),
                            ("HotspotKey-basic.entitlements", "text.plist.entitlements")]),
    ("Resources", "Resources", [("Assets.xcassets", "folder.assetcatalog")]),
]


def uid(key: str) -> str:
    return hashlib.md5(key.encode()).hexdigest()[:24].upper()


def ref(name: str) -> str:
    return uid("ref:" + name)


def group_uid(name: str) -> str:
    return uid("group:" + name)


ROOT_GROUP = uid("group:__root__")
SOURCE_GROUP = uid("group:__source_root__")
PRODUCTS_GROUP = uid("group:__products__")
TARGET = uid("target:" + APP)
PROJECT = uid("project:" + APP)
PRODUCT_REF = uid("product:" + APP)
SOURCES_PHASE = uid("phase:sources")
FRAMEWORKS_PHASE = uid("phase:frameworks")
RESOURCES_PHASE = uid("phase:resources")
PROJ_CFG_LIST = uid("cfglist:project")
TARGET_CFG_LIST = uid("cfglist:target")
CFG_PROJ_DEBUG = uid("cfg:project:debug")
CFG_PROJ_RELEASE = uid("cfg:project:release")
CFG_TGT_DEBUG = uid("cfg:target:debug")
CFG_TGT_RELEASE = uid("cfg:target:release")


def build_objects() -> tuple[str, str, str, str, str]:
    """返回 (fileRef 段, buildFile 段, 各组段, sources 列表, resources 列表)"""
    ref_lines, build_lines, group_lines = [], [], []
    source_ids, resource_ids = [], []

    group_lines.append(
        f'\t\t{ROOT_GROUP} = {{\n'
        f'\t\t\tisa = PBXGroup;\n'
        f'\t\t\tchildren = (\n'
        f'\t\t\t\t{SOURCE_GROUP} /* {APP} */,\n'
        f'\t\t\t\t{PRODUCTS_GROUP} /* Products */,\n'
        f'\t\t\t);\n'
        f'\t\t\tsourceTree = "<group>";\n'
        f'\t\t}};\n'
    )
    group_lines.append(
        f'\t\t{SOURCE_GROUP} /* {APP} */ = {{\n'
        f'\t\t\tisa = PBXGroup;\n'
        f'\t\t\tchildren = (\n'
        + "".join(f'\t\t\t\t{group_uid(n)} /* {n} */,\n' for n, _, _ in GROUPS)
        + f'\t\t\t);\n'
        f'\t\t\tpath = {APP};\n'
        f'\t\t\tsourceTree = "<group>";\n'
        f'\t\t}};\n'
    )
    group_lines.append(
        f'\t\t{PRODUCTS_GROUP} /* Products */ = {{\n'
        f'\t\t\tisa = PBXGroup;\n'
        f'\t\t\tchildren = (\n'
        f'\t\t\t\t{PRODUCT_REF} /* {APP}.app */,\n'
        f'\t\t\t);\n'
        f'\t\t\tname = Products;\n'
        f'\t\t\tsourceTree = "<group>";\n'
        f'\t\t}};\n'
    )

    for group_name, group_path, files in GROUPS:
        children = []
        for filename, ftype in files:
            fid = ref(group_name + "/" + filename)
            children.append(f'\t\t\t\t{fid} /* {filename} */,\n')
            ref_lines.append(
                f'\t\t{fid} /* {filename} */ = {{isa = PBXFileReference; '
                f'lastKnownFileType = {ftype}; path = {filename}; sourceTree = "<group>"; }};\n'
            )
            if ftype == "sourcecode.swift":
                bid = uid("build:" + group_name + "/" + filename)
                source_ids.append((bid, filename))
                build_lines.append(
                    f'\t\t{bid} /* {filename} in Sources */ = {{isa = PBXBuildFile; '
                    f'fileRef = {fid} /* {filename} */; }};\n'
                )
            elif ftype == "folder.assetcatalog":
                bid = uid("build:" + group_name + "/" + filename)
                resource_ids.append((bid, filename))
                build_lines.append(
                    f'\t\t{bid} /* {filename} in Resources */ = {{isa = PBXBuildFile; '
                    f'fileRef = {fid} /* {filename} */; }};\n'
                )

        group_lines.append(
            f'\t\t{group_uid(group_name)} /* {group_name} */ = {{\n'
            f'\t\t\tisa = PBXGroup;\n'
            f'\t\t\tchildren = (\n'
            + "".join(children)
            + f'\t\t\t);\n'
            f'\t\t\tpath = {group_path};\n'
            f'\t\t\tsourceTree = "<group>";\n'
            f'\t\t}};\n'
        )

    ref_lines.append(
        f'\t\t{PRODUCT_REF} /* {APP}.app */ = {{isa = PBXFileReference; '
        f'explicitFileType = wrapper.application; includeInIndex = 0; '
        f'path = {APP}.app; sourceTree = BUILT_PRODUCTS_DIR; }};\n'
    )
    return "".join(ref_lines), "".join(build_lines), "".join(group_lines), \
        "".join(f'\t\t\t\t{bid} /* {name} in Sources */,\n' for bid, name in source_ids), \
        "".join(f'\t\t\t\t{bid} /* {name} in Resources */,\n' for bid, name in resource_ids)


PROJECT_SETTINGS = {
    "ALWAYS_SEARCH_USER_PATHS": "NO",
    "CLANG_ANALYZER_NONNULL": "YES",
    "CLANG_ENABLE_MODULES": "YES",
    "CLANG_ENABLE_OBJC_ARC": "YES",
    "CLANG_WARN_BOOL_CONVERSION": "YES",
    "CLANG_WARN_DOCUMENTATION_COMMENTS": "YES",
    "CLANG_WARN_EMPTY_BODY": "YES",
    "CLANG_WARN_UNREACHABLE_CODE": "YES",
    "COPY_PHASE_STRIP": "NO",
    "ENABLE_STRICT_OBJC_MSGSEND": "YES",
    "GCC_C_LANGUAGE_STANDARD": "gnu17",
    "GCC_NO_COMMON_BLOCKS": "YES",
    "GCC_WARN_UNINITIALIZED_AUTOS": "YES_AGGRESSIVE",
    "GCC_WARN_UNUSED_FUNCTION": "YES",
    "GCC_WARN_UNUSED_VARIABLE": "YES",
    "IPHONEOS_DEPLOYMENT_TARGET": DEPLOYMENT_TARGET,
    "SDKROOT": "iphoneos",
    "SWIFT_VERSION": "5.0",
}

PROJECT_DEBUG = dict(PROJECT_SETTINGS, **{
    "DEBUG_INFORMATION_FORMAT": "dwarf",
    "ENABLE_TESTABILITY": "YES",
    "GCC_OPTIMIZATION_LEVEL": "0",
    "GCC_PREPROCESSOR_DEFINITIONS": '(\n\t\t\t\t\t"DEBUG=1",\n\t\t\t\t\t"$(inherited)",\n\t\t\t\t)',
    "MTL_ENABLE_DEBUG_INFO": "INCLUDE_SOURCE",
    "ONLY_ACTIVE_ARCH": "YES",
    "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG",
    "SWIFT_OPTIMIZATION_LEVEL": "-Onone",
})

PROJECT_RELEASE = dict(PROJECT_SETTINGS, **{
    "DEBUG_INFORMATION_FORMAT": '"dwarf-with-dsym"',
    "ENABLE_NS_ASSERTIONS": "NO",
    "MTL_ENABLE_DEBUG_INFO": "NO",
    "SWIFT_COMPILATION_MODE": "wholemodule",
    "SWIFT_OPTIMIZATION_LEVEL": "-O",
    "VALIDATE_PRODUCT": "YES",
})

TARGET_COMMON = {
    "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
    "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
    "CODE_SIGN_STYLE": "Automatic",
    "CURRENT_PROJECT_VERSION": "1",
    "DEVELOPMENT_TEAM": '""',
    "ENABLE_PREVIEWS": "YES",
    "GENERATE_INFOPLIST_FILE": "NO",
    "INFOPLIST_FILE": f"{APP}/Support/Info.plist",
    "CODE_SIGN_ENTITLEMENTS": f"{APP}/Support/HotspotKey-basic.entitlements",
    "LD_RUNPATH_SEARCH_PATHS": '(\n\t\t\t\t\t"$(inherited)",\n\t\t\t\t\t"@executable_path/Frameworks",\n\t\t\t\t)',
    "MARKETING_VERSION": "1.1.0",
    "PRODUCT_BUNDLE_IDENTIFIER": BUNDLE_ID,
    "PRODUCT_NAME": '"$(TARGET_NAME)"',
    "SUPPORTED_PLATFORMS": '"iphoneos iphonesimulator"',
    "SUPPORTS_MACCATALYST": "NO",
    "SWIFT_EMIT_LOC_STRINGS": "YES",
    "SWIFT_VERSION": "5.0",
    "TARGETED_DEVICE_FAMILY": '"1,2"',
}


def build_settings(d: dict[str, str], indent: str = "\t\t\t\t") -> str:
    return "".join(f"{indent}{k} = {v};\n" for k, v in d.items())


SCHEME_DIR = ROOT / "HotspotKey.xcodeproj" / "xcshareddata" / "xcschemes"


def write_scheme() -> pathlib.Path:
    """生成 shared scheme —— 没有它 CI 上 `xcodebuild -scheme` 会直接报错"""
    ref = (
        f'<BuildableReference\n'
        f'               BuildableIdentifier = "primary"\n'
        f'               BlueprintIdentifier = "{TARGET}"\n'
        f'               BuildableName = "{APP}.app"\n'
        f'               BlueprintName = "{APP}"\n'
        f'               ReferencedContainer = "container:{APP}.xcodeproj">\n'
        f'            </BuildableReference>'
    )
    runnable = (
        f'<BuildableProductRunnable\n'
        f'            runnableDebuggingMode = "0">\n'
        f'            {ref}\n'
        f'         </BuildableProductRunnable>'
    )

    xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme
   LastUpgradeVersion = "1520"
   version = "1.7">
   <BuildAction
      parallelizeBuildables = "YES"
      buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry
            buildForTesting = "YES"
            buildForRunning = "YES"
            buildForProfiling = "YES"
            buildForArchiving = "YES"
            buildForAnalyzing = "YES">
            {ref}
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      shouldUseLaunchSchemeArgsEnv = "YES">
      <Testables>
      </Testables>
   </TestAction>
   <LaunchAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      launchStyle = "0"
      useCustomWorkingDirectory = "NO"
      ignoresPersistentStateOnLaunch = "NO"
      debugDocumentVersioning = "YES"
      debugServiceExtension = "internal"
      allowLocationSimulation = "YES">
      {runnable}
   </LaunchAction>
   <ProfileAction
      buildConfiguration = "Release"
      shouldUseLaunchSchemeArgsEnv = "YES"
      savedToolIdentifier = ""
      useCustomWorkingDirectory = "NO"
      debugDocumentVersioning = "YES">
      {runnable}
   </ProfileAction>
   <AnalyzeAction
      buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction
      buildConfiguration = "Release"
      revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
'''
    SCHEME_DIR.mkdir(parents=True, exist_ok=True)
    path = SCHEME_DIR / f"{APP}.xcscheme"
    path.write_text(xml, encoding="utf-8")
    return path


def main() -> int:
    refs, builds, groups, sources, resources = build_objects()

    text = f"""// !$*UTF8*$!
{{
	archiveVersion = 1;
	classes = {{
	}};
	objectVersion = 56;
	objects = {{

/* Begin PBXBuildFile section */
{builds}/* End PBXBuildFile section */

/* Begin PBXFileReference section */
{refs}/* End PBXFileReference section */

/* Begin PBXFrameworksBuildPhase section */
		{FRAMEWORKS_PHASE} /* Frameworks */ = {{
			isa = PBXFrameworksBuildPhase;
			buildActionMask = 2147483647;
			files = (
			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXFrameworksBuildPhase section */

/* Begin PBXGroup section */
{groups}/* End PBXGroup section */

/* Begin PBXNativeTarget section */
		{TARGET} /* {APP} */ = {{
			isa = PBXNativeTarget;
			buildConfigurationList = {TARGET_CFG_LIST} /* Build configuration list for PBXNativeTarget "{APP}" */;
			buildPhases = (
				{SOURCES_PHASE} /* Sources */,
				{FRAMEWORKS_PHASE} /* Frameworks */,
				{RESOURCES_PHASE} /* Resources */,
			);
			buildRules = (
			);
			dependencies = (
			);
			name = {APP};
			productName = {APP};
			productReference = {PRODUCT_REF} /* {APP}.app */;
			productType = "com.apple.product-type.application";
		}};
/* End PBXNativeTarget section */

/* Begin PBXProject section */
		{PROJECT} /* Project object */ = {{
			isa = PBXProject;
			attributes = {{
				BuildIndependentTargetsInParallel = 1;
				LastSwiftUpdateCheck = 1520;
				LastUpgradeCheck = 1520;
				TargetAttributes = {{
					{TARGET} = {{
						CreatedOnToolsVersion = 15.2;
					}};
				}};
			}};
			buildConfigurationList = {PROJ_CFG_LIST} /* Build configuration list for PBXProject "{APP}" */;
			compatibilityVersion = "Xcode 14.0";
			developmentRegion = zh_CN;
			hasScannedForEncodings = 0;
			knownRegions = (
				zh_CN,
				en,
				Base,
			);
			mainGroup = {ROOT_GROUP};
			productRefGroup = {PRODUCTS_GROUP} /* Products */;
			projectDirPath = "";
			projectRoot = "";
			targets = (
				{TARGET} /* {APP} */,
			);
		}};
/* End PBXProject section */

/* Begin PBXResourcesBuildPhase section */
		{RESOURCES_PHASE} /* Resources */ = {{
			isa = PBXResourcesBuildPhase;
			buildActionMask = 2147483647;
			files = (
{resources}			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXResourcesBuildPhase section */

/* Begin PBXSourcesBuildPhase section */
		{SOURCES_PHASE} /* Sources */ = {{
			isa = PBXSourcesBuildPhase;
			buildActionMask = 2147483647;
			files = (
{sources}			);
			runOnlyForDeploymentPostprocessing = 0;
		}};
/* End PBXSourcesBuildPhase section */

/* Begin XCBuildConfiguration section */
		{CFG_PROJ_DEBUG} /* Debug */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
{build_settings(PROJECT_DEBUG) if True else ""}			}};
			name = Debug;
		}};
		{CFG_PROJ_RELEASE} /* Release */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
{build_settings(PROJECT_RELEASE)}			}};
			name = Release;
		}};
		{CFG_TGT_DEBUG} /* Debug */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
{build_settings(TARGET_COMMON)}			}};
			name = Debug;
		}};
		{CFG_TGT_RELEASE} /* Release */ = {{
			isa = XCBuildConfiguration;
			buildSettings = {{
{build_settings(TARGET_COMMON)}			}};
			name = Release;
		}};
/* End XCBuildConfiguration section */

/* Begin XCConfigurationList section */
		{PROJ_CFG_LIST} /* Build configuration list for PBXProject "{APP}" */ = {{
			isa = XCConfigurationList;
			buildConfigurations = (
				{CFG_PROJ_DEBUG} /* Debug */,
				{CFG_PROJ_RELEASE} /* Release */,
			);
			defaultConfigurationIsVisible = 0;
			defaultConfigurationName = Release;
		}};
		{TARGET_CFG_LIST} /* Build configuration list for PBXNativeTarget "{APP}" */ = {{
			isa = XCConfigurationList;
			buildConfigurations = (
				{CFG_TGT_DEBUG} /* Debug */,
				{CFG_TGT_RELEASE} /* Release */,
			);
			defaultConfigurationIsVisible = 0;
			defaultConfigurationName = Release;
		}};
/* End XCConfigurationList section */
	}};
	rootObject = {PROJECT} /* Project object */;
}}
"""

    PROJ.parent.mkdir(parents=True, exist_ok=True)
    PROJ.write_text(text, encoding="utf-8")
    print(f"written: {PROJ}  ({len(text)} bytes)")

    # 结构自检
    depth = 0
    for ch in text:
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth < 0:
                print("!! 花括号提前闭合", file=sys.stderr)
                return 1
    if depth != 0:
        print(f"!! 花括号不平衡，剩余深度 {depth}", file=sys.stderr)
        return 1
    print("brace check: ok")

    scheme = write_scheme()
    print(f"written: {scheme}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
