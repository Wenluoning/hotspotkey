#!/usr/bin/env python3
"""
make_ipa.py — 把一个已编译的 .app 打包成 .ipa（Payload 结构）

.ipa 本质就是一个 zip：Payload/YourApp.app/...
打包本身不需要 macOS，任何有 python3 的机器都能做。
（能不能装到手机上，取决于 .app 是否用你的证书签过名。）

用法：
  python3 scripts/make_ipa.py build/Release-iphoneos/HotspotKey.app
  python3 scripts/make_ipa.py Some.app -o dist/HotspotKey.ipa
  python3 scripts/make_ipa.py --skeleton            # 生成结构样张，仅用于校验打包链路

选项：
  -o/--output   输出 ipa 路径（默认 dist/<App 名>.ipa）
  -q/--quiet    不打印每个文件的明细
"""

from __future__ import annotations

import argparse
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent


def pack(app_dir: pathlib.Path, output: pathlib.Path, quiet: bool) -> int:
    if not app_dir.exists() or app_dir.suffix != ".app":
        print(f"不是有效的 .app 目录：{app_dir}", file=sys.stderr)
        return 2

    files = sorted(p for p in app_dir.rglob("*") if p.is_file())
    if not files:
        print(f"{app_dir} 里没有文件", file=sys.stderr)
        return 2

    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    total = 0
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            rel = path.relative_to(app_dir)
            arcname = f"Payload/{app_dir.name}/{rel.as_posix()}"
            # 可执行文件与符号链接按 store 存，保持权限位
            info = zipfile.ZipInfo.from_file(path, arcname)
            info.compress_type = zipfile.ZIP_DEFLATED
            with open(path, "rb") as fh:
                data = fh.read()
            zf.writestr(info, data)
            total += len(data)
            if not quiet:
                print(f"  + Payload/{app_dir.name}/{rel.as_posix()}  ({len(data):,} B)")

    size = output.stat().st_size
    print()
    print(f"✓ 生成 {output}")
    print(f"  文件数 {len(files)}，原始 {total:,} B，压缩后 {size:,} B")

    # 自检：重新读一遍，确认 Payload 结构完整
    with zipfile.ZipFile(output) as zf:
        names = zf.namelist()
        bad = zf.testzip()
    if bad:
        print(f"!! 压缩包损坏：{bad}", file=sys.stderr)
        return 1
    if not all(n.startswith("Payload/") for n in names):
        print("!! 存在不在 Payload/ 下的条目", file=sys.stderr)
        return 1
    print("  校验通过：所有条目位于 Payload/ 下")
    return 0


def skeleton() -> int:
    """生成结构样张：没有可执行文件，不能安装，只用来验证打包脚本本身。"""
    import plistlib

    stage = ROOT / "build" / "skeleton" / "HotspotKey.app"
    stage.mkdir(parents=True, exist_ok=True)

    info = {
        "CFBundleDisplayName": "钥匙通",
        "CFBundleExecutable": "HotspotKey",
        "CFBundleIdentifier": "com.yg.hotspotkey",
        "CFBundleName": "HotspotKey",
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": "1.0.0",
        "CFBundleVersion": "1",
        "LSRequiresIPhoneOS": True,
        "MinimumOSVersion": "16.0",
        "NSLocationWhenInUseUsageDescription": "iOS 把 WiFi 名称视为位置信息，需要定位权限才能显示当前 SSID。",
        "UILaunchScreen": {},
        "UISupportedInterfaceOrientations": ["UIInterfaceOrientationPortrait"],
    }
    with open(stage / "Info.plist", "wb") as fh:
        plistlib.dump(info, fh)

    (stage / "PkgInfo").write_bytes(b"APPL????")

    # 占位可执行文件（真正编译后由 xcodebuild 产出，这里仅占位）
    executable = stage / "HotspotKey"
    executable.write_bytes(b"\x00" * 16)
    executable.chmod(0o755)

    res = stage / "Assets.car"
    res.write_bytes(b"\x00" * 8)

    print(f"样张目录：{stage}")
    return pack(stage, ROOT / "dist" / "HotspotKey-skeleton.ipa", quiet=False)


def main() -> int:
    ap = argparse.ArgumentParser(description="把 .app 打成 .ipa")
    ap.add_argument("app", nargs="?", help="已编译的 .app 目录")
    ap.add_argument("-o", "--output", help="输出 ipa 路径")
    ap.add_argument("-q", "--quiet", action="store_true")
    ap.add_argument("--skeleton", action="store_true", help="生成结构样张 ipa")
    args = ap.parse_args()

    if args.skeleton:
        return skeleton()
    if not args.app:
        ap.print_help()
        return 2

    app_dir = pathlib.Path(args.app).resolve()
    output = pathlib.Path(args.output).resolve() if args.output \
        else ROOT / "dist" / f"{app_dir.stem}.ipa"
    return pack(app_dir, output, quiet=args.quiet)


if __name__ == "__main__":
    raise SystemExit(main())
