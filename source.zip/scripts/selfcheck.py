#!/usr/bin/env python3
"""
selfcheck.py — 在没有 Xcode 的机器上能做的工程自检

检查项：
  1. Swift 源文件的括号是否平衡（粗筛语法断裂）
  2. project.pbxproj 的 UUID 是否唯一、长度是否合法
  3. 每个 .swift 是否都进了 Sources 编译阶段，资源是否进了 Resources
  4. Info.plist / entitlements 是否为合法 plist
  5. Assets.xcassets 的 Contents.json 是否合法，引用的图片是否真的存在
  6. 每个 View/Service 引用的类型是否有定义（按文件名 + struct/class/enum 粗查）

这不是编译器，只用来提前发现结构性问题。真正的语法/类型检查必须跑 xcodebuild。
"""

from __future__ import annotations

import json
import pathlib
import plistlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "HotspotKey"
PBX = ROOT / "HotspotKey.xcodeproj" / "project.pbxproj"

problems: list[str] = []
notes: list[str] = []


def fail(msg: str) -> None:
    problems.append(msg)


# ---------- 1. 括号平衡 ----------

def strip_strings_and_comments(code: str) -> str:
    out, i, n = [], 0, len(code)
    while i < n:
        ch = code[i]
        if ch == "/" and i + 1 < n and code[i + 1] == "/":
            while i < n and code[i] != "\n":
                i += 1
        elif ch == "/" and i + 1 < n and code[i + 1] == "*":
            i += 2
            while i + 1 < n and not (code[i] == "*" and code[i + 1] == "/"):
                i += 1
            i += 2
        elif ch == '"':
            i += 1
            while i < n:
                if code[i] == "\\":
                    i += 2
                    continue
                if code[i] == '"':
                    i += 1
                    break
                i += 1
        else:
            out.append(ch)
            i += 1
    return "".join(out)


swift_files = sorted(SRC.rglob("*.swift"))
if not swift_files:
    fail("没找到任何 .swift 文件")

for path in swift_files:
    code = strip_strings_and_comments(path.read_text(encoding="utf-8"))
    for open_ch, close_ch, name in (("{", "}", "花括号"), ("(", ")", "圆括号"), ("[", "]", "方括号")):
        depth = 0
        for ch in code:
            if ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth < 0:
                    break
        if depth != 0:
            fail(f"{path.relative_to(ROOT)}: {name}不平衡（剩余 {depth}）")
notes.append(f"Swift 文件 {len(swift_files)} 个，括号检查完成")

# ---------- 2/3. pbxproj ----------

text = PBX.read_text(encoding="utf-8")

uuids = re.findall(r"\b([0-9A-F]{24})\b", text)
dupes = {u for u in set(uuids) if uuids.count(u) > 1}
if dupes:
    # 同一 UUID 会在定义 + 引用处多次出现，这里只查「定义行」重复
    definitions: dict[str, int] = {}
    for line in text.splitlines():
        m = re.match(r"\s*([0-9A-F]{24})\s+/\*.*?\*/\s*=\s*\{", line)
        if m:
            definitions[m.group(1)] = definitions.get(m.group(1), 0) + 1
    dup_defs = [u for u, c in definitions.items() if c > 1]
    if dup_defs:
        fail(f"pbxproj 有重复定义的对象 ID: {dup_defs}")
notes.append(f"pbxproj 对象 ID 共 {len(set(uuids))} 个，均 24 位十六进制")

sources_block = re.search(r"PBXSourcesBuildPhase section \*/(.*?)/\* End PBXSourcesBuildPhase", text, re.S)
resources_block = re.search(r"PBXResourcesBuildPhase section \*/(.*?)/\* End PBXResourcesBuildPhase", text, re.S)
sources_text = sources_block.group(1) if sources_block else ""
resources_text = resources_block.group(1) if resources_block else ""

sources_names = set(re.findall(r"/\* (.+?) in Sources \*/,\s*$", sources_text, re.M))
resources_names = set(re.findall(r"/\* (.+?) in Resources \*/,\s*$", resources_text, re.M))

for path in swift_files:
    if path.name not in sources_names:
        fail(f"{path.name} 没有出现在 Sources 编译阶段")
if "Assets.xcassets" not in resources_names:
    fail("Assets.xcassets 没有出现在 Resources 阶段")
for required in ("INFOPLIST_FILE", "PRODUCT_BUNDLE_IDENTIFIER", "SWIFT_VERSION",
                 "ASSETCATALOG_COMPILER_APPICON_NAME", "CODE_SIGN_ENTITLEMENTS"):
    if required not in text:
        fail(f"pbxproj 缺少构建设置 {required}")

# 括号平衡（pbxproj 用大括号）
depth = 0
for ch in text:
    if ch == "{":
        depth += 1
    elif ch == "}":
        depth -= 1
if depth != 0:
    fail(f"pbxproj 花括号不平衡（剩余 {depth}）")

# ---------- 4. plist ----------

for name in ("Info.plist", "HotspotKey.entitlements", "HotspotKey-basic.entitlements"):
    path = SRC / "Support" / name
    try:
        with open(path, "rb") as fh:
            data = plistlib.load(fh)
        if not isinstance(data, dict):
            fail(f"{name} 顶层不是字典")
    except Exception as exc:  # noqa: BLE001
        fail(f"{name} 不是合法 plist：{exc}")

info = plistlib.loads((SRC / "Support" / "Info.plist").read_bytes())
for key in ("NSLocationWhenInUseUsageDescription", "CFBundleExecutable",
            "CFBundlePackageType", "UILaunchScreen"):
    if key not in info:
        fail(f"Info.plist 缺少 {key}")
notes.append("Info.plist / entitlements 解析正常")

# ---------- 5. Assets ----------

for contents in (SRC / "Resources" / "Assets.xcassets").rglob("Contents.json"):
    try:
        data = json.loads(contents.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        fail(f"{contents.relative_to(ROOT)} 不是合法 JSON：{exc}")
        continue
    for image in data.get("images", []):
        filename = image.get("filename")
        if filename and not (contents.parent / filename).exists():
            fail(f"{contents.relative_to(ROOT)} 引用了不存在的 {filename}")
notes.append("Assets.xcassets 结构与图片引用正常")

# ---------- 6. 类型定义粗查 ----------

declared: set[str] = set()
for path in swift_files:
    code = path.read_text(encoding="utf-8")
    declared |= set(re.findall(r"\b(?:struct|class|enum|protocol|extension)\s+([A-Za-z_][A-Za-z0-9_]*)", code))

used = set()
for path in swift_files:
    code = path.read_text(encoding="utf-8")
    used |= set(re.findall(r"\b([A-Z][A-Za-z0-9]{3,})\s*\(", code))

known_external = {
    "SwiftUI", "Foundation", "UIKit", "Combine", "CryptoKit", "Security", "CoreLocation",
    "NetworkExtension", "ForEach", "NavigationStack", "NavigationLink", "TabView", "VStack",
    "HStack", "ZStack", "ScrollView", "List", "Form", "Section", "Picker", "Toggle", "Button",
    "TextField", "SecureField", "Spacer", "Text", "Image", "Label", "ProgressView", "ShareLink",
    "RoundedRectangle", "Capsule", "Circle", "LinearGradient", "JSONEncoder", "JSONDecoder",
    "Date", "String", "Int", "Double", "Bool", "Data", "URL", "Task", "Array", "Set", "Result",
    "Timer", "Bundle", "FileManager", "UIPasteboard", "UIApplication", "Color", "Font",
    "SymmetricalKey", "SymmetricKey", "AES", "CLLocationManager", "NEHotspotConfiguration",
    "NEHotspotConfigurationManager", "NSError", "CFTypeRef", "CheckedContinuation",
    "DispatchQueue", "Never", "Void", "Preview", "EnvironmentObject", "StateObject", "State",
    "Binding", "ObservableObject", "Published", "Content", "Identifiable", "Hashable",
    "Codable", "CaseIterable", "Error", "LocalizedError", "NSObject", "StringProtocol",
}
unknown = sorted(used - declared - known_external)
if unknown:
    notes.append(f"以下大写标识符未在本工程声明（可能是系统 API）：{', '.join(unknown[:12])}")

# ---------- 输出 ----------

print("== 自检结果 ==")
for line in notes:
    print("  ·", line)
if problems:
    print()
    for line in problems:
        print("  ✗", line)
    print(f"\n共 {len(problems)} 项问题")
    sys.exit(1)
print("\n✓ 全部通过（结构层面）")
