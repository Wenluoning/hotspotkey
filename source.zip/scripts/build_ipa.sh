#!/usr/bin/env bash
#
# build_ipa.sh — 在 macOS（装了 Xcode）上一键产出 HotspotKey.ipa
#
# 用法：
#   ./scripts/build_ipa.sh                    # 有开发者证书：archive + export 出可安装 ipa
#   ./scripts/build_ipa.sh --unsigned         # 不签名编译，产出未签名 ipa（给 Sideloadly/AltStore 自签）
#   ./scripts/build_ipa.sh --entitlements full  # 启用 WiFi 连接所需的完整 entitlement
#   ./scripts/build_ipa.sh --exports           # 生成 ExportOptions.plist 就停下
#
# 环境变量：
#   DEVELOPMENT_TEAM  你的 Team ID（10 位），证书签名的 ipa 需要
#   EXPORT_METHOD     development | ad-hoc | app-store-connect  （默认 development）
#
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
APP="HotspotKey"
PROJECT="${APP}.xcodeproj"
SCHEME="${APP}"
BUILD_DIR="${ROOT}/build"
DIST_DIR="${ROOT}/dist"
ARCHIVE="${BUILD_DIR}/${APP}.xcarchive"
EXPORT_METHOD="${EXPORT_METHOD:-development}"
TEAM="${DEVELOPMENT_TEAM:-}"
SIGNED=1
ENTITLEMENTS="basic"

for arg in "$@"; do
  case "$arg" in
    --unsigned) SIGNED=0 ;;
    --exports)  SIGNED="exports" ;;
    *) : ;;
  esac
done
# 单独扫 --entitlements 后面的取值
prev=""
for arg in "$@"; do
  if [[ "$prev" == "--entitlements" ]]; then ENTITLEMENTS="$arg"; fi
  prev="$arg"
done

case "$ENTITLEMENTS" in
  full) ENT_FILE="${APP}/Support/HotspotKey.entitlements"
        echo "== entitlements: full（需要带 Hotspot Configuration 权限的付费账号签）" ;;
  *)    ENT_FILE="${APP}/Support/HotspotKey-basic.entitlements"
        echo "== entitlements: basic（任何账号可签，但不含 WiFi 连接权限）" ;;
esac

if [[ ! -d "$PROJECT" ]]; then
  echo "找不到 ${PROJECT}，先跑：python3 scripts/gen_pbxproj.py"
  exit 1
fi
mkdir -p "$BUILD_DIR" "$DIST_DIR"

write_export_options() {
  local path="$1"
  cat > "$path" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key><string>${EXPORT_METHOD}</string>
  <key>signingStyle</key><string>automatic</string>
  <key>stripSwiftSymbols</key><true/>
  <key>compileBitcode</key><false/>
  <key>destination</key><string>export</string>
  <key>teamID</key><string>${TEAM}</string>
</dict>
</plist>
PLIST
  echo "已写 ExportOptions.plist（method=${EXPORT_METHOD}）"
}

if [[ "$SIGNED" == "exports" ]]; then
  write_export_options "${ROOT}/ExportOptions.plist"
  exit 0
fi

common_args=(
  -project "$PROJECT"
  -scheme "$SCHEME"
  -configuration Release
  -destination 'generic/platform=iOS'
  CODE_SIGN_ENTITLEMENTS="$ENT_FILE"
  CURRENT_PROJECT_VERSION=1
  MARKETING_VERSION=1.1.0
)

if [[ "$SIGNED" == "1" ]]; then
  if [[ -z "$TEAM" ]]; then
    echo "!! 没设置 DEVELOPMENT_TEAM。"
    echo "   export DEVELOPMENT_TEAM=ABCDE12345 && ./scripts/build_ipa.sh"
    echo "   或者走未签名：./scripts/build_ipa.sh --unsigned"
    exit 1
  fi
  echo "== 1/3 Archive"
  xcodebuild "${common_args[@]}" \
    -archivePath "$ARCHIVE" \
    DEVELOPMENT_TEAM="$TEAM" \
    -allowProvisioningUpdates \
    archive

  echo "== 2/3 写 ExportOptions"
  write_export_options "${ROOT}/ExportOptions.plist"

  echo "== 3/3 Export ipa"
  xcodebuild -exportArchive \
    -archivePath "$ARCHIVE" \
    -exportOptionsPlist "${ROOT}/ExportOptions.plist" \
    -exportPath "$DIST_DIR" \
    -allowProvisioningUpdates

  IPA="$(find "$DIST_DIR" -maxdepth 1 -name '*.ipa' | head -n 1 || true)"
  if [[ -n "$IPA" ]]; then
    echo
    echo "✓ 完成：$IPA"
    ls -lh "$IPA"
  else
    echo "!! 导出没有产出 ipa，检查 ./build/*.xcarchive 与 ExportOptions.plist"
    exit 1
  fi
else
  echo "== 未签名编译（不签名、不要求证书）"
  xcodebuild "${common_args[@]}" \
    -derivedDataPath "$BUILD_DIR/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY="" \
    build

  APP_PATH="$(find "$BUILD_DIR/DerivedData/Build/Products/Release-iphoneos" -maxdepth 1 -name '*.app' | head -n 1)"
  if [[ -z "$APP_PATH" ]]; then
    echo "!! 找不到编译产物 .app"
    exit 1
  fi
  echo "== 用 make_ipa.py 打包：$APP_PATH"
  python3 scripts/make_ipa.py "$APP_PATH"
  echo
  echo "✓ 未签名 ipa 在 dist/ 下，用 Sideloadly / AltStore / TrollStore 自签安装。"
fi
