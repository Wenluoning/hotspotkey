//
//  HotspotDetailView.swift
//  详情：看密码、连接、反馈
//

import SwiftUI

struct HotspotDetailView: View {
    @EnvironmentObject private var store: HotspotStore
    @EnvironmentObject private var wifi: WiFiManager

    let hotspot: Hotspot

    @State private var showPassword = false
    @State private var joinOnce = false
    @State private var result: String?
    @State private var resultIsGood = false
    @State private var showQR = false

    /// 取库里最新的一份（连接结果会回写计数）
    private var live: Hotspot {
        store.hotspots.first { $0.id == hotspot.id } ?? hotspot
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                header
                passwordCard
                connectCard
                qrCard
                metaCard
                if live.isMine { removeButton }
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle(live.ssid)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showQR) {
            QRShareSheet(hotspot: live)
        }
    }

    private var qrCard: some View {
        Button {
            showQR = true
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "qrcode")
                    .font(.system(size: 17, weight: .semibold))
                VStack(alignment: .leading, spacing: 2) {
                    Text("生成分享二维码").font(.subheadline.weight(.medium))
                    Text("别人用相机扫一下就能连，不用报密码")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.tertiary)
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var header: some View {
        Card {
            VStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [.accentColor.opacity(0.9), .accentColor.opacity(0.45)],
                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 68, height: 68)
                    Image(systemName: live.security.symbol)
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(.white)
                }
                Text(live.ssid).font(.title3.weight(.bold))
                HStack(spacing: 8) {
                    HeatBadge(hotspot: live)
                    Text(live.security.label)
                        .font(.caption2.weight(.semibold))
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Color.secondary.opacity(0.12), in: Capsule())
                    if wifi.isConnected(to: live) {
                        Text("已连接")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(Color.green.opacity(0.16), in: Capsule())
                            .foregroundStyle(.green)
                    }
                }
                Text(live.bssidShort)
                    .font(.caption.monospaced())
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity)
        }
    }

    private var passwordCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("密码").font(.subheadline.weight(.semibold))
                    Spacer()
                    Button(showPassword ? "隐藏" : "显示") {
                        withAnimation { showPassword.toggle() }
                    }
                    .font(.caption.weight(.semibold))
                    .disabled(live.password.isEmpty)
                }

                if live.security == .open {
                    Text("开放网络，无需密码")
                        .font(.title3)
                        .foregroundStyle(.secondary)
                } else {
                    Text(showPassword ? live.password : live.maskedPassword)
                        .font(.system(.title3, design: .monospaced).weight(.semibold))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }

                CopyButton(value: live.password)
            }
        }
    }

    private var connectCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Toggle(isOn: $joinOnce) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("一次性连接").font(.subheadline.weight(.medium))
                        Text("断开后系统不再自动重连，适合公共热点")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
                .tint(.accentColor)

                Button {
                    Task { await connect() }
                } label: {
                    HStack {
                        if wifi.isConnecting {
                            ProgressView().tint(.white)
                        } else {
                            Image(systemName: "bolt.horizontal.fill")
                        }
                        Text(wifi.isConnecting ? "正在连接…" : "一键连接")
                            .font(.headline)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .background(Color.accentColor, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    .foregroundStyle(.white)
                }
                .buttonStyle(.plain)
                .disabled(wifi.isConnecting)

                if let result {
                    Label(result, systemImage: resultIsGood ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .font(.footnote)
                        .foregroundStyle(resultIsGood ? .green : .orange)
                }

                if wifi.isConnected(to: live) {
                    Button(role: .destructive) {
                        wifi.forget(ssid: live.ssid)
                    } label: {
                        Text("断开并忘记此网络")
                            .font(.subheadline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.red)
                }
            }
        }
    }

    private var metaCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 9) {
                InfoRow(key: "共享人", value: live.sharedBy)
                InfoRow(key: "共享时间", value: live.sharedAt.formatted(date: .abbreviated, time: .shortened))
                InfoRow(key: "连接记录", value: "成功 \(live.successCount) / 失败 \(live.failCount)")
                InfoRow(key: "成功率", value: "\(Int(live.successRate * 100))%")
                if let note = live.note, !note.isEmpty {
                    InfoRow(key: "备注", value: note)
                }
                if store.mine.contains(where: { $0.id == live.id }) {
                    InfoRow(key: "来源", value: "我上传的")
                }
            }
        }
    }

    private var removeButton: some View {
        Button(role: .destructive) {
            store.remove(live)
        } label: {
            Text("从我的共享中删除")
                .font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(Color.red.opacity(0.1), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        }
        .buttonStyle(.plain)
        .foregroundStyle(.red)
    }

    // MARK: - 动作

    private func connect() async {
        result = nil
        let ok = await wifi.connect(to: live, joinOnce: joinOnce)
        store.report(live, success: ok)
        resultIsGood = ok
        if ok {
            result = "已连接，网络名 “\(live.ssid)”"
        } else {
            result = wifi.lastError ?? "连接失败，请确认密码或信号"
        }
        wifi.refreshCurrentNetwork()
    }
}
