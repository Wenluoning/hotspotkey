//
//  LibraryView.swift
//  密码库：搜索、排序、删除
//

import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var store: HotspotStore
    @EnvironmentObject private var wifi: WiFiManager
    @State private var pendingDelete: Hotspot?

    var body: some View {
        VStack(spacing: 0) {
            Picker("排序", selection: $store.sortMode) {
                ForEach(HotspotStore.SortMode.allCases) { mode in
                    Text(mode.label).tag(mode)
                }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)

            if store.filtered.isEmpty {
                Spacer()
                EmptyStateView(symbol: "magnifyingglass",
                               title: "没有匹配的记录",
                               message: "换个关键词，或者到“共享”页添加。")
                Spacer()
            } else {
                List {
                    ForEach(store.filtered) { hotspot in
                        NavigationLink(value: hotspot) {
                            HotspotRow(hotspot: hotspot, isCurrent: wifi.isConnected(to: hotspot))
                        }
                        .listRowInsets(EdgeInsets(top: 2, leading: 0, bottom: 2, trailing: 8))
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                pendingDelete = hotspot
                            } label: {
                                Label("删除", systemImage: "trash")
                            }
                            if !hotspot.password.isEmpty {
                                Button {
                                    UIPasteboard.general.string = hotspot.password
                                } label: {
                                    Label("复制", systemImage: "doc.on.doc")
                                }
                                .tint(.blue)
                            }
                        }
                    }
                }
                .listStyle(.plain)
            }
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("密码库")
        .searchable(text: $store.searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "SSID / 备注 / 共享人")
        .navigationDestination(for: Hotspot.self) { hotspot in
            HotspotDetailView(hotspot: hotspot)
        }
        .confirmationDialog("删除这条记录？",
                            isPresented: Binding(get: { pendingDelete != nil },
                                                 set: { if !$0 { pendingDelete = nil } }),
                            presenting: pendingDelete) { hotspot in
            Button("删除 \(hotspot.ssid)", role: .destructive) {
                store.remove(hotspot)
                pendingDelete = nil
            }
            Button("取消", role: .cancel) { pendingDelete = nil }
        } message: { _ in
            Text("只删除本机记录，不影响其他人。")
        }
    }
}
