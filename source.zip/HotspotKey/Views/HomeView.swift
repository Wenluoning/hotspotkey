//
//  HomeView.swift
//  附近：当前网络 + 推荐热点
//

import SwiftUI
import CoreLocation

struct HomeView: View {
    @EnvironmentObject private var store: HotspotStore
    @EnvironmentObject private var wifi: WiFiManager
    @EnvironmentObject private var engine: AutoJoinEngine

    @AppStorage("autocrack.silent") private var silent = false

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                currentNetworkCard
                crackCard
                permissionHint
                quickStats
                nearbySection
                iosLimitNote
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("附近")
        .refreshable {
            wifi.refreshCurrentNetwork()
            try? await Task.sleep(nanoseconds: 400_000_000)
        }
        .onAppear { wifi.refreshCurrentNetwork() }
    }

    // MARK: - 当前网络

    private var currentNetworkCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(colors: [.accentColor, .accentColor.opacity(0.55)],
                                                 startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 42, height: 42)
                        Image(systemName: wifi.currentSSID == nil ? "wifi.slash" : "wifi")
                            .font(.system(size: 19, weight: .semibold))
                            .foregroundStyle(.white)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text(wifi.currentSSID ?? "未连接 WiFi")
                            .font(.headline)
                            .lineLimit(1)
                        Text(wifi.currentBSSID.map { "BSSID \($0.uppercased())" } ?? "点右上角刷新")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    Button {
                        wifi.refreshCurrentNetwork()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 15, weight: .semibold))
                            .padding(9)
                            .background(Color.accentColor.opacity(0.12), in: Circle())
                    }
                    .buttonStyle(.plain)
                }

                if let message = wifi.lastMessage {
                    Label(message, systemImage: "checkmark.circle.fill")
                        .font(.footnote)
                        .foregroundStyle(.green)
                }
                if let error = wifi.lastError {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote)
                        .foregroundStyle(.orange)
                }
            }
        }
    }

    // MARK: - 一键蹭网

    private var crackCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 13) {
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(colors: [Color.accentColor, Color.accentColor.opacity(0.5)],
                                                 startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 42, height: 42)
                        Image(systemName: "bolt.horizontal.fill")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundStyle(Color.white)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("一键蹭网").font(.headline)
                        Text(silent ? "静默模式 · 不显示网络名" : "不输密码，自动匹配共享库")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    Toggle("", isOn: $silent)
                        .labelsHidden()
                        .tint(.accentColor)
                        .scaleEffect(0.82)
                }

                if engine.isRunning {
                    ProgressView(value: engine.progress)
                        .tint(.accentColor)
                }

                Text(crackStatusText)
                    .font(.subheadline)
                    .foregroundStyle(statusTint)
                    .lineLimit(2)

                if !engine.log.isEmpty {
                    VStack(alignment: .leading, spacing: 2) {
                        let recent = Array(engine.log.suffix(3))
                        ForEach(Array(recent.indices), id: \.self) { index in
                            Text(recent[index])
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundStyle(.tertiary)
                                .lineLimit(1)
                        }
                    }
                }

                Button {
                    toggleCrack()
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: engine.isRunning ? "stop.fill" : "bolt.fill")
                            .font(.system(size: 14, weight: .bold))
                        Text(engine.isRunning ? "停止" : "开始自动连网")
                            .font(.headline)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .background(
                        engine.isRunning
                        ? AnyShapeStyle(Color.secondary.opacity(0.15))
                        : AnyShapeStyle(Color.accentColor),
                        in: RoundedRectangle(cornerRadius: 13, style: .continuous)
                    )
                    .foregroundStyle(engine.isRunning ? Color.primary : Color.white)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var crackStatusText: String {
        switch engine.phase {
        case .idle:
            return "点一下，自动试探库里所有候选网络"
        case .running(let ssid, let index, let total, let note):
            return "正在试探 \(ssid)  [\(index)/\(total)] · \(note)"
        case .success(let ssid, let guessed):
            if silent { return "已连接" }
            return guessed
                ? "已连接 \(ssid)，密码是猜出来的，已存进密码库"
                : "已连接 \(ssid)，密码已写入系统"
        case .exhausted:
            return "这轮没命中。换个位置再试，或在设置里同步在线库"
        case .stopped:
            return "已停止"
        case .empty:
            return "密码库是空的，先去「共享」页加几条"
        case .unauthorized:
            return "签名缺少 Hotspot Configuration 权限，连不上"
        }
    }

    private var statusTint: Color {
        switch engine.phase {
        case .success:                return .green
        case .exhausted, .unauthorized: return .orange
        case .running:                return .primary
        default:                      return .secondary
        }
    }

    private func toggleCrack() {
        if engine.isRunning {
            engine.stop()
        } else {
            engine.crack(store: store, wifi: wifi)
        }
    }

    // MARK: - 权限提示

    private var permissionHint: some View {
        Group {
            if !wifi.hasLocationPermission {
                Card {
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "location.slash.fill")
                            .foregroundStyle(.orange)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("需要定位权限才能读到 WiFi 名称")
                                .font(.subheadline.weight(.semibold))
                            Text("iOS 把 SSID 当作位置信息，没有授权时系统只会返回空值。")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Button("去授权") { wifi.requestPermission() }
                                .font(.caption.weight(.semibold))
                                .padding(.top, 2)
                        }
                    }
                }
            }
        }
    }

    private var quickStats: some View {
        HStack(spacing: 10) {
            statTile("密码库", "\(store.stats.total)", "key.fill")
            statTile("我的共享", "\(store.stats.mine)", "person.fill")
            statTile("开放网络", "\(store.stats.open)", "wifi")
        }
    }

    private func statTile(_ title: String, _ value: String, _ symbol: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: symbol)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color.accentColor)
            Text(value).font(.title3.weight(.bold))
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.secondarySystemGroupedBackground),
                    in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    // MARK: - 推荐列表

    private var nearbySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("可用热点").font(.headline)
                Spacer()
                NavigationLink("全部") {
                    LibraryView()
                }
                .font(.subheadline.weight(.medium))
            }
            .padding(.top, 4)

            let list = Array(store.nearby(excluding: wifi.currentSSID).prefix(6))
            if list.isEmpty {
                Card {
                    EmptyStateView(symbol: "questionmark.folder",
                                   title: "密码库里还没有记录",
                                   message: "到“共享”页手动录入一个 WiFi，或在“密码库”里恢复示例数据。")
                }
            } else {
                VStack(spacing: 0) {
                    ForEach(list) { hotspot in
                        NavigationLink {
                            HotspotDetailView(hotspot: hotspot)
                        } label: {
                            HotspotRow(hotspot: hotspot, isCurrent: wifi.isConnected(to: hotspot))
                        }
                        .buttonStyle(.plain)
                        if hotspot.id != list.last?.id {
                            Divider().padding(.leading, 52)
                        }
                    }
                }
                .background(Color(.secondarySystemGroupedBackground),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
    }

    private var iosLimitNote: some View {
        Card {
            VStack(alignment: .leading, spacing: 6) {
                Label("为什么没有“扫描附近 WiFi”", systemImage: "info.circle")
                    .font(.footnote.weight(.semibold))
                Text("iOS 不向第三方 App 开放扫描接口，也无法读取别人路由器的密码。这里列的是你库里已收录的网络，点“连接”后才由系统去验证密码对不对。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

// MARK: - 行

struct HotspotRow: View {
    let hotspot: Hotspot
    var isCurrent: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(Color.accentColor.opacity(hotspot.heat > 0.6 ? 0.16 : 0.08))
                    .frame(width: 36, height: 36)
                SecurityIcon(security: hotspot.security)
                    .foregroundStyle(Color.accentColor)
            }

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(hotspot.ssid)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(1)
                    if isCurrent {
                        Text("已连接")
                            .font(.system(size: 10, weight: .bold))
                            .padding(.horizontal, 5).padding(.vertical, 2)
                            .background(Color.green.opacity(0.18), in: Capsule())
                            .foregroundStyle(.green)
                    }
                }
                HStack(spacing: 6) {
                    Text(hotspot.security.label)
                    Text("·")
                    Text(hotspot.sharedBy)
                    Text("·")
                    Text("\(Int(hotspot.successRate * 100))% 成功")
                }
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }

            Spacer(minLength: 4)

            VStack(alignment: .trailing, spacing: 4) {
                SignalBars(heat: hotspot.heat)
                HeatBadge(hotspot: hotspot)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .contentShape(Rectangle())
    }
}
