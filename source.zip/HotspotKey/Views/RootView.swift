//
//  RootView.swift
//  底部四个页签：附近 / 密码库 / 共享 / 设置
//  同时负责把「到访地点」事件接到自动试连引擎上
//

import SwiftUI

struct RootView: View {
    @EnvironmentObject private var store: HotspotStore
    @EnvironmentObject private var wifi: WiFiManager
    @Environment(\.scenePhase) private var scenePhase

    @StateObject private var engine = AutoJoinEngine()
    @StateObject private var siteStore = SiteStore()
    @StateObject private var watcher = RegionWatcher()

    @State private var tab: Tab = .nearby
    @State private var pendingAutoCrack = false
    /// 本轮试连对应的地点，命中后回写统计
    @State private var lastSiteID: UUID?

    enum Tab: Hashable { case nearby, library, share, settings }

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack {
                HomeView()
            }
            .tabItem { Label("附近", systemImage: "wifi") }
            .tag(Tab.nearby)

            NavigationStack {
                LibraryView()
            }
            .tabItem { Label("密码库", systemImage: "key.fill") }
            .tag(Tab.library)

            NavigationStack {
                ShareView()
            }
            .tabItem { Label("共享", systemImage: "square.and.arrow.up") }
            .tag(Tab.share)

            NavigationStack {
                SettingsView()
            }
            .tabItem { Label("设置", systemImage: "gearshape") }
            .tag(Tab.settings)
        }
        .tint(.accentColor)
        .environmentObject(engine)
        .environmentObject(siteStore)
        .environmentObject(watcher)
        .onAppear(perform: setup)
        .onChange(of: scenePhase) { phase in
            // 后台收到到访事件时不能调 apply（系统会拒），回到前台再跑
            guard phase == .active, pendingAutoCrack else { return }
            pendingAutoCrack = false
            startCrackIfAllowed()
        }
        .onChange(of: engine.phase) { phase in
            guard case .success = phase,
                  let id = lastSiteID,
                  let site = siteStore.sites.first(where: { $0.id == id }) else { return }
            siteStore.markCracked(site, hits: 1)
            lastSiteID = nil
        }
    }

    // MARK: - 地点联动

    private func setup() {
        wifi.requestPermission()
        siteStore.bootstrap()

        watcher.onEnter = { event in
            handleArrival(event)
        }

        if UserDefaults.standard.bool(forKey: RegionSettings.enabledKey) {
            watcher.enable()
            watcher.syncRegions(with: siteStore.monitored)
        }
    }

    private func handleArrival(_ event: VisitEvent) {
        // 先记账，前台后台都记
        let site = siteStore.record(latitude: event.latitude,
                                    longitude: event.longitude,
                                    name: event.name)
        lastSiteID = site.id
        watcher.syncRegions(with: siteStore.monitored)

        guard UserDefaults.standard.bool(forKey: RegionSettings.autoCrackKey) else { return }

        if scenePhase == .active {
            startCrackIfAllowed()
        } else {
            pendingAutoCrack = true
        }
    }

    private func startCrackIfAllowed() {
        guard !engine.isRunning else { return }
        engine.crack(store: store, wifi: wifi)
    }
}

/// 地点相关设置的 key，Settings 与本文件共用
enum RegionSettings {
    static let enabledKey = "region.enabled"
    static let autoCrackKey = "region.autoCrack"
}

#Preview {
    RootView()
        .environmentObject(HotspotStore())
        .environmentObject(WiFiManager())
}
