//
//  Components.swift
//  共用小组件
//

import SwiftUI
import UIKit

/// 卡片容器
struct Card<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color(.secondarySystemGroupedBackground))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.primary.opacity(0.06), lineWidth: 1)
            )
    }
}

/// 四格信号条，长度由热度决定
struct SignalBars: View {
    let heat: Double
    var tint: Color = .accentColor

    var body: some View {
        HStack(alignment: .bottom, spacing: 2) {
            ForEach(0..<4, id: \.self) { index in
                let threshold = Double(index + 1) / 4.0
                Capsule()
                    .fill(heat >= threshold - 0.25 ? tint : Color.secondary.opacity(0.25))
                    .frame(width: 3.5, height: CGFloat(5 + index * 4))
            }
        }
        .frame(height: 18, alignment: .bottom)
    }
}

/// 热度徽标
struct HeatBadge: View {
    let hotspot: Hotspot

    private var tint: Color {
        switch hotspot.heat {
        case 0.72...: return .green
        case 0.45..<0.72: return .orange
        default: return .secondary
        }
    }

    var body: some View {
        Text(hotspot.heatLabel)
            .font(.caption2.weight(.semibold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(tint.opacity(0.15), in: Capsule())
            .foregroundStyle(tint)
    }
}

/// 锁定状态图标
struct SecurityIcon: View {
    let security: Security

    var body: some View {
        Image(systemName: security.symbol)
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(security == .open ? Color.orange : Color.secondary)
    }
}

/// 空状态
struct EmptyStateView: View {
    let symbol: String
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: symbol)
                .font(.system(size: 38, weight: .light))
                .foregroundStyle(.tertiary)
            Text(title).font(.headline)
            Text(message)
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 36)
    }
}

/// 复制到剪贴板 + 轻提示
struct CopyButton: View {
    let value: String
    @State private var copied = false

    var body: some View {
        Button {
            UIPasteboard.general.string = value
            withAnimation { copied = true }
            Task {
                try? await Task.sleep(nanoseconds: 1_400_000_000)
                withAnimation { copied = false }
            }
        } label: {
            Label(copied ? "已复制" : "复制密码", systemImage: copied ? "checkmark" : "doc.on.doc")
                .font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(Color.accentColor.opacity(0.13), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(value.isEmpty)
    }
}

/// 一行键值
struct InfoRow: View {
    let key: String
    let value: String

    var body: some View {
        HStack(alignment: .top) {
            Text(key)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .frame(width: 76, alignment: .leading)
            Text(value)
                .font(.subheadline)
                .foregroundStyle(.primary)
                .textSelection(.enabled)
            Spacer(minLength: 0)
        }
    }
}
