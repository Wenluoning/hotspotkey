//
//  SettingsView.swift
//  权限状态、数据管理、关于
//

import SwiftUI
import UIKit
import CoreLocation

struct SettingsView: View {
    @EnvironmentObject private var store: HotspotStore
    @EnvironmentObject private var wifi: WiFiManager
    @EnvironmentObject private var engine: AutoJoinEngine
    @EnvironmentObject private var watcher: RegionWatcher
    @EnvironmentObject private var siteStore: SiteStore

    @AppStorage(HotspotAPI.baseURLKey) private var relayURL: String = ""
    @AppStorage("autocrack.silent") private var silent = false
    @AppStorage("autocrack.deep") private var deepGuess = false
    @AppStorage(RegionSettings.enabledKey) private var regionEnabled = false
    @AppStorage(RegionSettings.autoCrackKey) private var autoCrack = false
    @State private var syncStatus: String?
    @State private var syncing = false
    @State private var preloading = false
    @State private var preloadResult: String?
    @State private var confirmPreload = false
    @State private var confirmReset = false
    @State private var confirmWipe = false
    @State private var exportText: String = ""

    private static let api = HotspotAPI()

    var body: some View {
        Form {
            Section {
                HStack {
                    Label("定位权限", systemImage: "location.fill")
                    Spacer()
                    Text(permissionText)
                        .foregroundStyle(wifi.hasLocationPermission ? .green : .orange)
                        .font(.subheadline)
                }
                if !wifi.hasLocationPermission {
                    Button("申请定位权限") { wifi.requestPermission() }
                    Button("打开系统设置") {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    }
                }
                HStack {
                    Label("当前网络", systemImage: "wifi")
                    Spacer()
                    Text(wifi.currentSSID ?? "—")
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            } header: {
                Text("权限与状态")
            } footer: {
                Text("读取 SSID 属于 iOS 的定位权限范围；连接热点还需要签名里带 Hotspot Configuration entitlement。")
            }

            Section {
                HStack {
                    Text("密码库条目")
                    Spacer()
                    Text("\(store.stats.total)").foregroundStyle(.secondary)
                }
                HStack {
                    Text("我共享的")
                    Spacer()
                    Text("\(store.stats.mine)").foregroundStyle(.secondary)
                }
                HStack {
                    Text("开放网络")
                    Spacer()
                    Text("\(store.stats.open)").foregroundStyle(.secondary)
                }
            } header: {
                Text("数据")
            }

            Section {
                Button {
                    exportText = store.exportText()
                } label: {
                    Label("生成导出文本", systemImage: "doc.text")
                }
                if !exportText.isEmpty {
                    ShareLink(item: exportText) {
                        Label("分享导出结果", systemImage: "square.and.arrow.up")
                    }
                }
                Button {
                    store.resetToSeed()
                } label: {
                    Label("恢复示例数据", systemImage: "arrow.counterclockwise")
                }
                Button(role: .destructive) {
                    confirmWipe = true
                } label: {
                    Label("清空我共享的全部记录", systemImage: "trash")
                }
                Button(role: .destructive) {
                    confirmReset = true
                } label: {
                    Label("重置为出厂示例库", systemImage: "exclamationmark.arrow.circlepath")
                }
            } header: {
                Text("数据管理")
            } footer: {
                Text("密码以 AES-GCM 加密后存放在 App 沙盒内，密钥保存在 Keychain，只在解除锁定后的本机可读。")
            }

            Section {
                Button {
                    confirmPreload = true
                } label: {
                    HStack(spacing: 8) {
                        if preloading {
                            ProgressView().controlSize(.small)
                        }
                        Label(preloading ? "预置中…" : "把库里网络预置进系统", systemImage: "square.stack.3d.up.fill")
                    }
                }
                .disabled(preloading || store.stats.total == 0)

                if let preloadResult {
                    Text(preloadResult)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Toggle(isOn: $silent) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("静默模式").font(.subheadline)
                        Text("连上后不显示网络名与密码，只提示已连接")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(.accentColor)

                Toggle(isOn: $deepGuess) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("深度猜测").font(.subheadline)
                        Text("每个网络最多试 12 个密码（默认 6 个）。命中率更高，耗时也翻倍")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(.accentColor)
            } header: {
                Text("自动连网")
            } footer: {
                Text("预置会把候选逐条写进 iOS 的已知网络，之后走到覆盖范围内手机会自己连，不用开 App。过程中会切换网络，当前连接会短暂中断。")
            }

            Section {
                Toggle(isOn: $regionEnabled) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("记录到访地点").font(.subheadline)
                        Text(watcher.statusLine)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(.accentColor)
                .onChange(of: regionEnabled) { enabled in
                    if enabled {
                        watcher.enable()
                        watcher.syncRegions(with: siteStore.monitored)
                    } else {
                        watcher.disable()
                    }
                }

                Toggle("到新地点自动试连", isOn: $autoCrack)
                    .tint(.accentColor)
                    .disabled(!regionEnabled)

                if siteStore.sites.isEmpty {
                    Text("还没有地点记录。开启后到访过的地方会自动出现在这里。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(siteStore.recent(5)) { site in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(site.shortName)
                                    .font(.subheadline)
                                    .lineLimit(1)
                                Text("到访 \(site.visits) 次 · 命中 \(site.crackHits) 次")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(site.lastVisitedAt.formatted(date: .omitted, time: .shortened))
                                .font(.caption2)
                                .foregroundStyle(.tertiary)
                        }
                    }
                    Button(role: .destructive) {
                        siteStore.removeAll()
                    } label: {
                        Label("清空地点记录", systemImage: "trash")
                    }
                }
            } header: {
                Text("地点自动连网")
            } footer: {
                Text("用 CLVisit 自动发现到访地点。iOS 只允许前台调用 WiFi 连接接口，所以后台到访只发通知并记账，回到 App 时补跑一轮试连；命中后网络写进系统已知网络，以后再到这里由系统自己连。最多注册 19 个地理围栏。")
            }

            Section {
                TextField("https://your-api.example.com", text: $relayURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .font(.callout)

                Button {
                    Task { await syncRemote() }
                } label: {
                    HStack(spacing: 8) {
                        if syncing {
                            ProgressView().controlSize(.small)
                        }
                        Text(syncing ? "同步中…" : "从在线库拉取")
                    }
                }
                .disabled(syncing || relayURL.trimmingCharacters(in: .whitespaces).isEmpty)

                if let syncStatus {
                    Text(syncStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } header: {
                Text("在线共享库")
            } footer: {
                Text("填自己的后端地址即启用众包共享；留空则完全离线。接口：GET /v1/hotspots?limit=50 返回 {\"items\":[...]}，POST /v1/hotspots 提交，POST /v1/reports 上报连接结果。")
            }

            Section {
                InfoRow(key: "版本", value: appVersion)
                InfoRow(key: "Bundle ID", value: Bundle.main.bundleIdentifier ?? "—")
                InfoRow(key: "架构", value: "SwiftUI · iOS 16+")
            } header: {
                Text("关于")
            }
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Text("能力边界").font(.footnote.weight(.semibold))
                    ForEach(limits, id: \.self) { line in
                        HStack(alignment: .top, spacing: 6) {
                            Text("•").foregroundStyle(.secondary)
                            Text(line).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.vertical, 2)
            }
        }
        .navigationTitle("设置")
        .confirmationDialog("清空我共享的记录？", isPresented: $confirmWipe) {
            Button("清空", role: .destructive) { store.removeAllMine() }
            Button("取消", role: .cancel) {}
        }
        .confirmationDialog("重置为示例库？当前所有记录会被覆盖。", isPresented: $confirmReset) {
            Button("重置", role: .destructive) { store.resetToSeed() }
            Button("取消", role: .cancel) {}
        }
        .confirmationDialog("预置会逐条切换网络，当前连接会中断。继续？", isPresented: $confirmPreload) {
            Button("开始预置") { Task { await runPreload() } }
            Button("取消", role: .cancel) {}
        }
    }

    private func syncRemote() async {
        syncing = true
        syncStatus = nil
        defer { syncing = false }
        do {
            let remote = try await Self.api.fetchHotspots(limit: 100)
            let added = store.merge(remote: remote)
            syncStatus = "同步完成：收到 \(remote.count) 条，新增 \(added) 条"
        } catch {
            syncStatus = "同步失败：\(error.localizedDescription)"
        }
    }

    private func runPreload() async {
        preloading = true
        preloadResult = nil
        defer { preloading = false }
        let result = await engine.preload(store: store, wifi: wifi)
        preloadResult = "预置完成：成功 \(result.ok) 条，未命中 \(result.miss) 条"
    }

    private var permissionText: String {
        switch wifi.authorization {
        case .authorizedAlways, .authorizedWhenInUse: return "已授权"
        case .denied: return "已拒绝"
        case .restricted: return "受限制"
        case .notDetermined: return "未询问"
        @unknown default: return "未知"
        }
    }

    private var appVersion: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        let b = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
        return "\(v) (\(b))"
    }

    private let limits: [String] = [
        "无法扫描周边 WiFi：iOS 未向第三方开放扫描接口。",
        "无法读取他人路由器密码：只能靠手动录入、扫码识别或在线库同步。",
        "无法后台自动连接：joinOnce 断线后需要用户再次操作。",
        "企业级 802.1X（EAP）认证需额外配置证书，本版未包含。"
    ]
}
