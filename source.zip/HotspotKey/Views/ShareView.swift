//
//  ShareView.swift
//  手动录入并共享一个 WiFi
//

import SwiftUI

struct ShareView: View {
    @EnvironmentObject private var store: HotspotStore
    @EnvironmentObject private var wifi: WiFiManager

    @State private var ssid = ""
    @State private var password = ""
    @State private var note = ""
    @State private var security: Security = .wpa2
    @State private var shareAsMine = true
    @State private var toast: String?
    @State private var toastIsGood = true
    @State private var showPassword = false
    @State private var showScanner = false

    private var ssidValid: Bool {
        let trimmed = ssid.trimmingCharacters(in: .whitespacesAndNewlines)
        return !trimmed.isEmpty && trimmed.count <= 32
    }

    private var passwordValid: Bool {
        security == .open || security.validate(password)
    }

    private var canSubmit: Bool { ssidValid && passwordValid }

    var body: some View {
        Form {
            Section {
                TextField("WiFi 名称（SSID）", text: $ssid)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .onChange(of: ssid) { newValue in
                        if newValue.count > 32 { ssid = String(newValue.prefix(32)) }
                    }

                if !wifi.currentSSID.isEmptyOrNil, let current = wifi.currentSSID, ssid != current {
                    Button {
                        ssid = current
                    } label: {
                        Label("填入当前网络 “\(current)”", systemImage: "arrow.down.circle")
                            .font(.footnote)
                    }
                }

                Button {
                    showScanner = true
                } label: {
                    Label("扫二维码自动填入", systemImage: "qrcode.viewfinder")
                        .font(.footnote.weight(.medium))
                }
            } header: {
                Text("网络")
            } footer: {
                Text("iOS 不提供扫描接口，SSID 需要手动输入、扫二维码，或从当前已连接的网络一键填入。")
            }

            Section {
                Picker("加密方式", selection: $security) {
                    ForEach(Security.allCases) { item in
                        Text(item.label).tag(item)
                    }
                }

                if security != .open {
                    HStack {
                        Group {
                            if showPassword {
                                TextField("密码", text: $password)
                            } else {
                                SecureField("密码", text: $password)
                            }
                        }
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                        Button {
                            showPassword.toggle()
                        } label: {
                            Image(systemName: showPassword ? "eye.slash" : "eye")
                                .foregroundStyle(.secondary)
                        }
                        .buttonStyle(.plain)
                    }

                    if !password.isEmpty && !passwordValid {
                        Label(security == .wep
                              ? "WEP 需 5/13 位字符，或 10/26 位十六进制"
                              : "WPA/WPA2/WPA3 密码需 8–63 位",
                              systemImage: "exclamationmark.circle")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }
            } header: {
                Text("安全")
            }

            Section {
                TextField("备注，比如：门店通用 / 前台可问（可选）", text: $note, axis: .vertical)
                    .lineLimit(2...4)

                Toggle("标记为我共享的", isOn: $shareAsMine)
                    .tint(.accentColor)
            } header: {
                Text("补充")
            }

            Section {
                Button {
                    submit()
                } label: {
                    Text("加入我的密码库")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                }
                .disabled(!canSubmit)
            }

            if let toast {
                Section {
                    Label(toast, systemImage: toastIsGood ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                        .font(.subheadline)
                        .foregroundStyle(toastIsGood ? .green : .orange)
                }
            }

            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Label("只共享你有权使用的网络", systemImage: "hand.raised.fill")
                        .font(.footnote.weight(.semibold))
                    Text("别人的家庭或公司网络，未经允许不要录入共享。本机库里只保存加密后的密码副本，不会自动上传到任何服务器。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("共享 WiFi")
        .scrollDismissesKeyboard(.interactively)
        .sheet(isPresented: $showScanner) {
            CameraScannerSheet { code in
                apply(code)
            }
        }
    }

    private func apply(_ code: WiFiQRCode) {
        ssid = code.ssid
        password = code.password
        security = code.security
        showPassword = false
        toastIsGood = true
        toast = "已识别二维码：\(code.ssid)，确认后加入密码库"
    }

    private func submit() {
        let trimmedSSID = ssid.trimmingCharacters(in: .whitespacesAndNewlines)
        let hotspot = Hotspot(ssid: trimmedSSID,
                              bssid: nil,
                              password: security == .open ? "" : password,
                              security: security,
                              sharedBy: shareAsMine ? "我" : "匿名",
                              sharedAt: Date(),
                              successCount: 0,
                              failCount: 0,
                              note: note.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : note,
                              isMine: shareAsMine)
        store.add(hotspot)
        toastIsGood = true
        toast = "已加入密码库：\(trimmedSSID)"
        ssid = ""
        password = ""
        note = ""
        security = .wpa2
        showPassword = false
    }
}

private extension Optional where Wrapped == String {
    var isEmptyOrNil: Bool { self?.isEmpty ?? true }
}
