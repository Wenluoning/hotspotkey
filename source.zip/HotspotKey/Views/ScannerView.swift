//
//  ScannerView.swift
//  相机扫码：识别 WIFI: 二维码，成功后回传解析结果
//

import SwiftUI
import AVFoundation
import UIKit

/// 弹出的扫码页
struct CameraScannerSheet: View {
    @Environment(\.dismiss) private var dismiss

    /// 解析成功才回调
    var onCode: (WiFiQRCode) -> Void

    @State private var permission = AVCaptureDevice.authorizationStatus(for: .video)
    @State private var hint: String?
    @State private var invalid = false
    @State private var handled = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                switch permission {
                case .authorized:
                    CameraPreview { raw in
                        handle(raw)
                    }
                    .ignoresSafeArea()

                    frameOverlay

                case .denied, .restricted:
                    deniedView

                case .notDetermined:
                    ProgressView()
                        .tint(.white)
                        .task { await requestAccess() }

                @unknown default:
                    deniedView
                }
            }
            .navigationTitle("扫一扫")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("关闭") { dismiss() }
                        .tint(.white)
                }
            }
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarBackground(Color.black.opacity(0.6), for: .navigationBar)
        }
    }

    private var frameOverlay: some View {
        VStack {
            Spacer()
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.9), lineWidth: 3)
                .frame(width: 230, height: 230)
                .overlay(alignment: .bottom) {
                    Text("对准 WiFi 二维码")
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(.white)
                        .padding(.vertical, 6)
                        .padding(.horizontal, 12)
                        .background(Color.black.opacity(0.45), in: Capsule())
                        .offset(y: 34)
                }

            if let hint {
                Text(hint)
                    .font(.footnote)
                    .foregroundStyle(invalid ? Color.orange : Color.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Color.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .padding(.top, 48)
            }

            Spacer()
            Text("也可以在系统相机里直接扫，iOS 会提示加入网络")
                .font(.caption2)
                .foregroundStyle(Color.white.opacity(0.6))
                .padding(.bottom, 28)
        }
    }

    private var deniedView: some View {
        VStack(spacing: 14) {
            Image(systemName: "camera.metering.unknown")
                .font(.system(size: 42, weight: .light))
                .foregroundStyle(Color.white.opacity(0.8))
            Text("没有相机权限")
                .font(.headline)
                .foregroundStyle(.white)
            Text("到「设置 › 钥匙通 › 相机」打开后即可扫码。")
                .font(.footnote)
                .foregroundStyle(Color.white.opacity(0.65))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            Button("打开设置") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            .font(.subheadline.weight(.semibold))
            .padding(.horizontal, 22)
            .padding(.vertical, 10)
            .background(Color.accentColor, in: Capsule())
            .foregroundStyle(.white)
            .buttonStyle(.plain)
        }
    }

    private func requestAccess() async {
        let granted = await AVCaptureDevice.requestAccess(for: .video)
        permission = granted ? .authorized : .denied
    }

    private func handle(_ raw: String) {
        guard !handled else { return }
        guard let code = WiFiQRCodeCodec.parse(raw) else {
            invalid = true
            hint = "这不是 WiFi 二维码，换个码试试"
            return
        }
        handled = true
        invalid = false
        hint = "已识别：\(code.ssid)"
        onCode(code)
        dismiss()
    }
}

// MARK: - 相机预览

struct CameraPreview: UIViewControllerRepresentable {
    var onCode: (String) -> Void

    func makeUIViewController(context: Context) -> ScannerViewController {
        let controller = ScannerViewController()
        controller.onCode = onCode
        return controller
    }

    func updateUIViewController(_ uiViewController: ScannerViewController, context: Context) {}
}

final class ScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCode: ((String) -> Void)?

    private let session = AVCaptureSession()
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var hasDelivered = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        configureSession()
    }

    private func configureSession() {
        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else { return }
        session.addInput(input)

        let output = AVCaptureMetadataOutput()
        guard session.canAddOutput(output) else { return }
        session.addOutput(output)
        output.setMetadataObjectsDelegate(self, queue: .main)
        output.metadataObjectTypes = [.qr]

        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.layer.bounds
        view.layer.addSublayer(layer)
        previewLayer = layer
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        hasDelivered = false
        let session = self.session
        guard !session.isRunning else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            session.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        let session = self.session
        guard session.isRunning else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            session.stopRunning()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.layer.bounds
    }

    // MARK: - AVCaptureMetadataOutputObjectsDelegate

    func metadataOutput(_ output: AVCaptureMetadataOutput,
                        didOutput metadataObjects: [AVMetadataObject],
                        from connection: AVCaptureConnection) {
        guard !hasDelivered,
              let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              let value = object.stringValue else { return }
        hasDelivered = true
        let session = self.session
        DispatchQueue.global(qos: .userInitiated).async {
            session.stopRunning()
        }
        onCode?(value)
    }
}

// MARK: - 二维码分享页

struct QRShareSheet: View {
    @Environment(\.dismiss) private var dismiss
    let hotspot: Hotspot

    @State private var qrImage: UIImage?
    @State private var copied = false

    private var payload: String { WiFiQRCodeCodec.string(for: hotspot) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    VStack(spacing: 14) {
                        if let qrImage {
                            Image(uiImage: qrImage)
                                .interpolation(.none)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 240, height: 240)
                                .padding(16)
                                .background(Color.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        } else {
                            ProgressView()
                                .frame(width: 240, height: 240)
                                .background(Color.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        }

                        VStack(spacing: 4) {
                            Text(hotspot.ssid)
                                .font(.headline)
                            Text(hotspot.security == .open ? "开放网络" : "密码已含在二维码中")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.top, 8)

                    Text("别人用系统相机扫这个码，iPhone 会直接提示「加入网络」，不用手动输密码。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)

                    VStack(spacing: 10) {
                        Button {
                            UIPasteboard.general.string = payload
                            withAnimation { copied = true }
                            Task {
                                try? await Task.sleep(nanoseconds: 1_400_000_000)
                                withAnimation { copied = false }
                            }
                        } label: {
                            Label(copied ? "已复制二维码内容" : "复制二维码内容",
                                  systemImage: copied ? "checkmark" : "doc.on.doc")
                                .font(.subheadline.weight(.medium))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color.accentColor.opacity(0.13),
                                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                        .buttonStyle(.plain)

                        ShareLink(item: payload) {
                            Label("分享文本", systemImage: "square.and.arrow.up")
                                .font(.subheadline.weight(.medium))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color.secondary.opacity(0.12),
                                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 24)

                    Text(payload)
                        .font(.system(.caption2, design: .monospaced))
                        .foregroundStyle(.tertiary)
                        .padding(.horizontal, 24)
                        .textSelection(.enabled)
                }
                .padding(.bottom, 24)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("分享 WiFi")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .task {
                if qrImage == nil {
                    qrImage = WiFiQRCodeCodec.image(for: payload, side: 260)
                }
            }
        }
    }
}
