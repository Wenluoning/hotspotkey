//
//  HotspotKeyApp.swift
//  HotspotKey — 共享 WiFi 密码库（iOS 教学/自用版）
//

import SwiftUI

@main
struct HotspotKeyApp: App {
    @StateObject private var store = HotspotStore()
    @StateObject private var wifi = WiFiManager()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(wifi)
                .preferredColorScheme(nil)
                .onAppear {
                    store.bootstrap()
                    wifi.requestPermission()
                }
        }
    }
}
