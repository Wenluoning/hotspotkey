//
//  QRCode.swift
//  WiFi 二维码编解码 + 图片渲染
//
//  标准格式（Android/iOS 相机都能识别）：
//    WIFI:T:WPA;S:MyNet;P:pass1234;H:false;;
//  字段值里的 \ ; , : " 需要反斜杠转义。
//

import Foundation
import UIKit
import CoreImage
import CoreImage.CIFilterBuiltins

/// 扫出来的一条 WiFi 信息
struct WiFiQRCode: Equatable {
    var ssid: String
    var password: String
    var security: Security
    var hidden: Bool = false
}

enum WiFiQRCodeCodec {
    private static let specials: Set<Character> = ["\\", ";", ",", ":", "\""]

    // MARK: - 解析

    /// 解析 `WIFI:` 开头的二维码串；不是该格式返回 nil
    static func parse(_ raw: String) -> WiFiQRCode? {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count > 5, text.uppercased().hasPrefix("WIFI:") else { return nil }
        text = String(text.dropFirst(5))

        var fields: [String: String] = [:]
        for segment in split(text, on: ";", limit: 64) where !segment.isEmpty {
            let pair = split(segment, on: ":", limit: 1)
            guard pair.count == 2 else { continue }
            let key = unescape(pair[0]).trimmingCharacters(in: .whitespaces).uppercased()
            fields[key] = unescape(pair[1])
        }

        guard let ssid = fields["S"], !ssid.isEmpty else { return nil }
        let type = (fields["T"] ?? "WPA").uppercased()
        let security: Security
        switch type {
        case "NOPASS", "NONE", "": security = .open
        case "WEP":               security = .wep
        default:                  security = .wpa2   // WPA / WPA2 / WPA3 / SAE 统一按 WPA 处理
        }

        return WiFiQRCode(ssid: ssid,
                          password: fields["P"] ?? "",
                          security: security,
                          hidden: (fields["H"] ?? "").lowercased() == "true")
    }

    // MARK: - 生成

    static func string(for hotspot: Hotspot) -> String {
        let type: String
        switch hotspot.security {
        case .open: type = "nopass"
        case .wep:  type = "WEP"
        default:    type = "WPA"
        }
        var text = "WIFI:T:\(type);S:\(escape(hotspot.ssid));"
        if hotspot.security != .open {
            text += "P:\(escape(hotspot.password));"
        }
        text += "H:false;;"
        return text
    }

    static func escape(_ value: String) -> String {
        var out = ""
        for ch in value {
            if specials.contains(ch) { out.append("\\") }
            out.append(ch)
        }
        return out
    }

    /// 去掉一层转义
    static func unescape(_ text: String) -> String {
        var out = ""
        var escaped = false
        for ch in text {
            if escaped {
                out.append(ch)
                escaped = false
                continue
            }
            if ch == "\\" {
                escaped = true
                continue
            }
            out.append(ch)
        }
        return out
    }

    /// 按分隔符切分，只认未转义的分隔符；转义序列原样保留，留给 unescape 统一解一层。
    /// 不能在切分阶段就解 `\;`，否则后续会被二次解码，密码里的反斜杠会被吞掉。
    private static func split(_ text: String, on separator: Character, limit: Int) -> [String] {
        var parts: [String] = []
        var current = ""
        var escaped = false
        for ch in text {
            if escaped {
                current.append("\\")
                current.append(ch)
                escaped = false
                continue
            }
            if ch == "\\" {
                escaped = true
                continue
            }
            if ch == separator && parts.count < limit {
                parts.append(current)
                current = ""
                continue
            }
            current.append(ch)
        }
        parts.append(current)
        return parts
    }

    // MARK: - 渲染

    /// 生成二维码 UIImage，side 是输出边长（pt × scale 后取整）
    static func image(for text: String, side: CGFloat = 240) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(text.utf8)
        filter.correctionLevel = "M"

        guard let output = filter.outputImage else { return nil }
        // 先放大再转位图，避免直接缩放导致边缘发虚
        let scale = max(1, (side * UIScreen.main.scale) / max(output.extent.width, 1))
        let scaled = output.transformed(by: CGAffineTransform(scaleX: scale, y: scale))

        let context = CIContext(options: [.useSoftwareRenderer: false])
        guard let cgImage = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}
