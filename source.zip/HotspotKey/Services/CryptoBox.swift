//
//  CryptoBox.swift
//  密码字段落盘加密：AES-GCM，密钥存在 Keychain
//

import Foundation
import CryptoKit
import Security

enum CryptoBox {
    private static let service = "com.yg.hotspotkey.vault"
    private static let account = "master-key"

    private static var cachedKey: SymmetricKey?

    /// 取（或首次生成）256 位主密钥
    static func masterKey() -> SymmetricKey {
        if let cachedKey { return cachedKey }

        if let data = readKeychain(), data.count == 32 {
            let key = SymmetricKey(data: data)
            cachedKey = key
            return key
        }

        let key = SymmetricKey(size: .bits256)
        let raw = key.withUnsafeBytes { Data($0) }
        writeKeychain(raw)
        cachedKey = key
        return key
    }

    /// 加密 → base64 字符串
    static func seal(_ plaintext: String) -> String {
        guard let data = plaintext.data(using: .utf8) else { return "" }
        do {
            let box = try AES.GCM.seal(data, using: masterKey())
            guard let combined = box.combined else { return "" }
            return "v1:" + combined.base64EncodedString()
        } catch {
            return ""
        }
    }

    /// base64 字符串 → 解密；无前缀的旧数据按明文返回
    static func open(_ stored: String) -> String {
        guard stored.hasPrefix("v1:") else { return stored }
        let b64 = String(stored.dropFirst(3))
        guard let combined = Data(base64Encoded: b64) else { return "" }
        do {
            let box = try AES.GCM.SealedBox(combined: combined)
            let data = try AES.GCM.open(box, using: masterKey())
            return String(decoding: data, as: UTF8.self)
        } catch {
            return ""
        }
    }

    // MARK: - Keychain

    private static func readKeychain() -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess else { return nil }
        return item as? Data
    }

    @discardableResult
    private static func writeKeychain(_ data: Data) -> Bool {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var attributes = base
        attributes[kSecValueData as String] = data
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(attributes as CFDictionary, nil) == errSecSuccess
    }
}
