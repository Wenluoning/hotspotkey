//
//  HotspotStore.swift
//  本地热点库：加载 / 保存 / 检索 / 反馈
//

import Foundation
import Combine

@MainActor
final class HotspotStore: ObservableObject {
    @Published private(set) var hotspots: [Hotspot] = []
    @Published var searchText: String = ""
    @Published var sortMode: SortMode = .heat

    enum SortMode: String, CaseIterable, Identifiable {
        case heat, recent, name
        var id: String { rawValue }
        var label: String {
            switch self {
            case .heat:   return "按成功率"
            case .recent: return "按时间"
            case .name:   return "按名称"
            }
        }
    }

    private var didBootstrap = false
    private let fileName = "hotspots.json"

    private var fileURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("HotspotKey", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir.appendingPathComponent(fileName)
    }

    private var encoder: JSONEncoder {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }

    private var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }

    // MARK: - 生命周期

    func bootstrap() {
        guard !didBootstrap else { return }
        didBootstrap = true
        if let loaded = loadFromDisk(), !loaded.isEmpty {
            hotspots = loaded
        } else {
            hotspots = SeedData.make()
            saveToDisk()
        }
    }

    // MARK: - 增删改

    func add(_ hotspot: Hotspot) {
        if let index = hotspots.firstIndex(where: {
            $0.ssid.caseInsensitiveCompare(hotspot.ssid) == .orderedSame
        }) {
            // 已存在则更新密码与时间
            var updated = hotspots[index]
            updated.password = hotspot.password
            updated.security = hotspot.security
            updated.sharedAt = Date()
            updated.sharedBy = hotspot.sharedBy
            updated.note = hotspot.note ?? updated.note
            hotspots[index] = updated
        } else {
            hotspots.append(hotspot)
        }
        saveToDisk()
    }

    func remove(_ hotspot: Hotspot) {
        hotspots.removeAll { $0.id == hotspot.id }
        saveToDisk()
    }

    func removeAllMine() {
        hotspots.removeAll { $0.isMine }
        saveToDisk()
    }

    /// 连接后回写结果，用于成功率排序
    func report(_ hotspot: Hotspot, success: Bool) {
        guard let index = hotspots.firstIndex(where: { $0.id == hotspot.id }) else { return }
        if success {
            hotspots[index].successCount += 1
        } else {
            hotspots[index].failCount += 1
        }
        hotspots[index].sharedAt = Date()
        saveToDisk()
    }

    // MARK: - 查询

    var filtered: [Hotspot] {
        let keyword = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        var list = hotspots
        if !keyword.isEmpty {
            list = list.filter {
                $0.ssid.localizedCaseInsensitiveContains(keyword)
                || ($0.note ?? "").localizedCaseInsensitiveContains(keyword)
                || $0.sharedBy.localizedCaseInsensitiveContains(keyword)
            }
        }
        switch sortMode {
        case .heat:   return list.sorted { $0.heat > $1.heat }
        case .recent: return list.sorted { $0.sharedAt > $1.sharedAt }
        case .name:   return list.sorted { $0.ssid.localizedStandardCompare($1.ssid) == .orderedAscending }
        }
    }

    var mine: [Hotspot] {
        hotspots.filter { $0.isMine }.sorted { $0.sharedAt > $1.sharedAt }
    }

    var openNetworks: [Hotspot] {
        filtered.filter { $0.security == .open }
    }

    /// 推荐的"附近"队列：热度前 8 条，且未连接
    func nearby(excluding ssid: String?) -> [Hotspot] {
        filtered.filter { hotspot in
            guard let ssid else { return true }
            return hotspot.ssid.caseInsensitiveCompare(ssid) != .orderedSame
        }
    }

    var stats: (total: Int, mine: Int, open: Int) {
        (hotspots.count, hotspots.filter { $0.isMine }.count, hotspots.filter { $0.security == .open }.count)
    }

    /// 导出为文本，供 Settings 里的分享使用
    func exportText() -> String {
        var lines = ["# HotspotKey 共享库导出 \(Date())", ""]
        for h in filtered {
            lines.append("SSID: \(h.ssid)")
            lines.append("BSSID: \(h.bssidShort)")
            lines.append("安全: \(h.security.label)")
            lines.append("密码: \(h.password)")
            lines.append("来源: \(h.sharedBy)")
            if let note = h.note { lines.append("备注: \(note)") }
            lines.append("成功率: \(Int(h.successRate * 100))% (\(h.successCount)/\(h.successCount + h.failCount))")
            lines.append("---")
        }
        return lines.joined(separator: "\n")
    }

    // MARK: - 落盘

    private func saveToDisk() {
        // 密码字段落盘前加密
        let sealed: [Hotspot] = hotspots.map { hotspot in
            var copy = hotspot
            copy.password = CryptoBox.seal(hotspot.password)
            return copy
        }
        guard let data = try? encoder.encode(sealed) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    private func loadFromDisk() -> [Hotspot]? {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? decoder.decode([Hotspot].self, from: data) else {
            return nil
        }
        return decoded.map { hotspot in
            var copy = hotspot
            copy.password = CryptoBox.open(hotspot.password)
            return copy
        }
    }

    func resetToSeed() {
        hotspots = SeedData.make()
        saveToDisk()
    }

    /// 合并在线库拉回来的条目：同 SSID 覆盖为远端版本（自己上传的保留本地副本），返回新增条数
    @discardableResult
    func merge(remote items: [Hotspot]) -> Int {
        var added = 0
        for item in items {
            if let index = hotspots.firstIndex(where: {
                $0.ssid.caseInsensitiveCompare(item.ssid) == .orderedSame
            }) {
                guard !hotspots[index].isMine else { continue }
                var merged = item
                merged.isMine = false
                hotspots[index] = merged
            } else {
                hotspots.append(item)
                added += 1
            }
        }
        if added > 0 || !items.isEmpty {
            saveToDisk()
        }
        return added
    }
}
