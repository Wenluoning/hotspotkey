//
//  AutoJoinEngine.swift
//  一键蹭网：用户不输入密码，后台批量试探共享库，命中即连
//
//  原理说明（也是 iOS 上唯一能走通的路）：
//  WPA2/WPA3 的连网授权由系统完成，App 只能提交「SSID + 密码」给
//  NEHotspotConfigurationManager，由系统返回成功或失败。于是：
//    把密码库里所有候选依次提交 → 成功的那个就是「附近存在且密码对」的网络。
//  这就是「试库」，和网络层的「扫描」无关，也和破解无关——密码本身来自共享库。
//
//  iOS 上没有的东西（决定这条路的边界）：
//    · 无 monitor mode、无 raw socket，抓不到 4-way 握手包，跑不了字典
//    · 无热点扫描接口，只能靠提交配置的成败反推周围有没有这个网络
//    · 并发提交会被系统拒绝，必须串行
//

import Foundation
import Combine

@MainActor
final class AutoJoinEngine: ObservableObject {

    enum Phase: Equatable {
        case idle
        case running(ssid: String, index: Int, total: Int)
        case success(ssid: String)
        case exhausted          // 全部候选都没连上
        case stopped            // 用户中断
        case empty              // 库是空的
        case unauthorized       // 签名缺 entitlement
    }

    /// 单次试探的超时：系统对「周围没这个网络」的响应可能很慢，超时就跳过
    private let attemptTimeout: TimeInterval = 9
    /// 两次试探之间的间隔，避免系统拒绝并发请求
    private let attemptGap: UInt64 = 700_000_000

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var isRunning = false
    @Published private(set) var log: [String] = []
    @Published private(set) var progress: Double = 0

    private var runner: Task<Void, Never>?

    // MARK: - 候选排序

    /**
     命中率排序：
       1. 开放网络（无需密码，最快命中）
       2. 历史失败次数少的
       3. 热度高（成功率 + 新鲜度）的
     */
    func ranked(_ items: [Hotspot], skipSsid: String? = nil) -> [Hotspot] {
        items
            .filter { item in
                guard let skipSsid else { return true }
                return item.ssid.caseInsensitiveCompare(skipSsid) != .orderedSame
            }
            .filter { $0.failCount < 3 }        // 连续失败三次的不再浪费时间
            .sorted { a, b in
                let aOpen = a.security == .open
                let bOpen = b.security == .open
                if aOpen != bOpen { return aOpen }
                if a.failCount != b.failCount { return a.failCount < b.failCount }
                return a.heat > b.heat
            }
    }

    // MARK: - 主流程

    func crack(store: HotspotStore, wifi: WiFiManager) {
        guard !isRunning else { return }

        isRunning = true
        log.removeAll()
        progress = 0
        phase = .running(ssid: "", index: 0, total: 0)

        runner = Task { [weak self] in
            guard let self else { return }

            // 1. 配了在线库就先拉一次，把候选补全
            await self.pullCloudLibrary(store: store)

            if !wifi.hasLocationPermission {
                self.log.append("提示：未授权定位，连上后可能读不到网络名")
            }
            await self.runAttempts(store: store, wifi: wifi)
        }
    }

    private func runAttempts(store: HotspotStore, wifi: WiFiManager) async {
        let queue = ranked(store.hotspots, skipSsid: wifi.currentSSID)

        guard !queue.isEmpty else {
            phase = .empty
            isRunning = false
            return
        }

        var unauthorizedStreak = 0

        for (index, item) in queue.enumerated() {
            if Task.isCancelled { break }

            phase = .running(ssid: item.ssid, index: index + 1, total: queue.count)
            progress = Double(index) / Double(queue.count)
            log.append("试探 \(item.ssid)  [\(index + 1)/\(queue.count)]")

            let ok = await connectWithTimeout(item, wifi: wifi)

            if ok {
                store.report(item, success: true)
                progress = 1
                phase = .success(ssid: item.ssid)
                log.append("✓ 命中 \(item.ssid)，已加入系统已知网络")
                wifi.refreshCurrentNetwork()
                isRunning = false
                return
            }

            store.report(item, success: false)
            log.append("✗ \(item.ssid) — \(wifi.lastError ?? "未命中")")

            // 连续多次被系统拒绝，说明签名没带 Hotspot Configuration 权限，
            // 继续试只是浪费时间和电
            if (wifi.lastError ?? "").contains("系统拒绝") {
                unauthorizedStreak += 1
                if unauthorizedStreak >= 2 {
                    phase = .unauthorized
                    isRunning = false
                    log.append("签名缺少 Hotspot Configuration 权限，已停止")
                    return
                }
            } else {
                unauthorizedStreak = 0
            }

            try? await Task.sleep(nanoseconds: attemptGap)
        }

        phase = Task.isCancelled ? .stopped : .exhausted
        isRunning = false
    }

    func stop() {
        runner?.cancel()
        runner = nil
        isRunning = false
        if case .running = phase { phase = .stopped }
    }

    // MARK: - 预置：把库里能连上的网络全部写进系统

    /**
     一次性把候选逐条 apply 到系统（joinOnce = false），连上的会被 iOS 记住。
     之后用户走到覆盖范围内，手机会自己连，连 App 都不用开。
     代价：过程中会不断切换网络，当前连接可能中断。
     */
    func preload(store: HotspotStore, wifi: WiFiManager) async -> (ok: Int, miss: Int) {
        var ok = 0
        var miss = 0
        let queue = ranked(store.hotspots)

        for item in queue.prefix(30) {
            if Task.isCancelled { break }
            log.append("预置 \(item.ssid)")
            if await connectWithTimeout(item, wifi: wifi) {
                ok += 1
            } else {
                miss += 1
            }
            try? await Task.sleep(nanoseconds: 900_000_000)
        }
        log.append("预置完成：成功 \(ok)，未命中 \(miss)")
        return (ok, miss)
    }

    // MARK: - 单次试探（带超时）

    private func connectWithTimeout(_ hotspot: Hotspot, wifi: WiFiManager) async -> Bool {
        let timeout = attemptTimeout

        return await withTaskGroup(of: Bool.self) { group in
            group.addTask { @MainActor in
                await wifi.connect(to: hotspot, joinOnce: false)
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                return false
            }
            let first = await group.next() ?? false
            group.cancelAll()
            return first
        }
    }

    // MARK: - 云端补库

    private func pullCloudLibrary(store: HotspotStore) async {
        guard HotspotAPI.configuredBaseURL != nil else { return }
        log.append("从在线库拉取候选…")

        let api = HotspotAPI()
        let fetch = Task { try await api.fetchHotspots(limit: 200) }
        let timeout = Task {
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            fetch.cancel()
        }
        defer { timeout.cancel() }

        if let remote = try? await fetch.value {
            let added = store.merge(remote: remote)
            log.append("在线库返回 \(remote.count) 条，新增 \(added) 条")
        } else {
            log.append("在线库不可用，改用本地库")
        }
    }
}
