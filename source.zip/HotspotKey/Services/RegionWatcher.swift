//
//  RegionWatcher.swift
//  地点触发：CLVisit 自动发现到访地点 + 圆形围栏进入提醒
//
//  为什么是"提醒 + 前台试连"而不是"后台静默连网"：
//  NEHotspotConfigurationManager 只接受前台调用，后台调用会被系统以
//  applicationIsNotInForeground 拒绝。所以真正让网络"自己连上"的办法是
//  预置（AutoJoinEngine.preload）——把配置提前写进系统已知网络。
//  本类负责的是：到新地点时及时提醒并跑一轮试连，把新网络补进系统。
//

import Foundation
import CoreLocation
import UserNotifications
import Combine

/// 一次到访事件
struct VisitEvent: Equatable {
    var latitude: Double
    var longitude: Double
    var name: String
    var at: Date
}

@MainActor
final class RegionWatcher: NSObject, ObservableObject {

    @Published private(set) var authorization: CLAuthorizationStatus = .notDetermined
    @Published private(set) var monitoring = false
    @Published private(set) var statusLine = "未开启"
    @Published private(set) var lastEntered: VisitEvent?

    /// 前台收到到访事件时回调（用于自动跑一轮试连）
    var onEnter: ((VisitEvent) -> Void)?

    private let manager = CLLocationManager()
    private var registered: [String: Site] = [:]
    private var geocoder: CLGeocoder?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        manager.distanceFilter = 80
        authorization = manager.authorizationStatus
    }

    // MARK: - 开关

    func enable() {
        Task {
            await requestNotificationPermission()
            if authorization == .notDetermined || authorization == .authorizedWhenInUse {
                manager.requestAlwaysAuthorization()
                statusLine = "等待用户授权「始终允许」定位"
            } else {
                startMonitoring()
            }
        }
    }

    func disable() {
        monitoring = false
        statusLine = "已关闭"
        manager.stopMonitoringVisits()
        for region in manager.monitoredRegions where region.identifier.hasPrefix("site-") {
            manager.stopMonitoring(for: region)
        }
        manager.allowsBackgroundLocationUpdates = false
    }

    private func startMonitoring() {
        guard authorization == .authorizedAlways else {
            monitoring = false
            statusLine = "需要「始终允许」定位权限才能后台监测地点"
            return
        }
        // Info.plist 里必须声明 UIBackgroundModes = location，否则下面这行会抛异常
        manager.allowsBackgroundLocationUpdates = true
        manager.pausesLocationUpdatesAutomatically = false
        manager.startMonitoringVisits()

        monitoring = true
        statusLine = "已开启：到访新地点会记录并提醒"
    }

    // MARK: - 围栏同步

    /// 把最近到访的地点注册成圆形围栏（iOS 上限 20 个，这里用 19 个）
    func syncRegions(with sites: [Site]) {
        guard monitoring else { return }

        registered = Dictionary(uniqueKeysWithValues: sites.map { (Self.regionID(for: $0.id), $0) })
        let wanted = Set(registered.keys)

        for region in manager.monitoredRegions
        where region.identifier.hasPrefix("site-") && !wanted.contains(region.identifier) {
            manager.stopMonitoring(for: region)
        }

        let current = Set(manager.monitoredRegions.map(\.identifier))
        for (identifier, site) in registered where !current.contains(identifier) {
            let radius = min(max(site.radius, 150), 1000)
            let region = CLCircularRegion(center: site.coordinate,
                                          radius: radius,
                                          identifier: identifier)
            region.notifyOnEntry = true
            region.notifyOnExit = false
            manager.startMonitoring(for: region)
        }
    }

    private static func regionID(for id: UUID) -> String { "site-\(id.uuidString)" }

    // MARK: - 事件处理

    private func handle(visitLatitude latitude: Double,
                        longitude: Double,
                        fallbackName: String) async {
        let name = await reverseName(latitude: latitude, longitude: longitude, fallback: fallbackName)
        let event = VisitEvent(latitude: latitude, longitude: longitude, name: name, at: Date())
        lastEntered = event
        notify(title: "到了新地方", body: "\(name) · 点开自动连网")
        onEnter?(event)
    }

    private func handleRegionEnter(identifier: String) {
        guard let site = registered[identifier] else { return }
        let event = VisitEvent(latitude: site.latitude,
                               longitude: site.longitude,
                               name: site.shortName,
                               at: Date())
        lastEntered = event
        notify(title: "进入常用地点", body: "\(site.shortName) · 试连一次补全已知网络")
        onEnter?(event)
    }

    private func reverseName(latitude: Double, longitude: Double, fallback: String) async -> String {
        let geocoder = self.geocoder ?? CLGeocoder()
        self.geocoder = geocoder
        let location = CLLocation(latitude: latitude, longitude: longitude)
        guard let placemarks = try? await geocoder.reverseGeocodeLocation(location),
              let placemark = placemarks.first else {
            return fallback
        }
        return placemark.name
            ?? placemark.thoroughfare
            ?? placemark.locality
            ?? fallback
    }

    // MARK: - 通知

    private func requestNotificationPermission() async {
        _ = try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound])
    }

    private func notify(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let request = UNNotificationRequest(identifier: UUID().uuidString,
                                            content: content,
                                            trigger: nil)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
}

// MARK: - CLLocationManagerDelegate

extension RegionWatcher: CLLocationManagerDelegate {

    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        Task { @MainActor in
            self.authorization = status
            if status == .authorizedAlways {
                self.startMonitoring()
            } else if status == .denied || status == .restricted {
                self.monitoring = false
                self.statusLine = "定位权限被拒绝，地点功能不可用"
            }
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didVisit visit: CLVisit) {
        let latitude = visit.coordinate.latitude
        let longitude = visit.coordinate.longitude
        guard latitude.isFinite, longitude.isFinite,
              latitude != 0, longitude != 0 else { return }
        let fallback = String(format: "%.4f, %.4f", latitude, longitude)

        Task { @MainActor in
            await self.handle(visitLatitude: latitude, longitude: longitude, fallbackName: fallback)
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        guard region.identifier.hasPrefix("site-") else { return }
        let identifier = region.identifier
        Task { @MainActor in
            self.handleRegionEnter(identifier: identifier)
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let message = error.localizedDescription
        Task { @MainActor in
            self.statusLine = "定位出错：\(message)"
        }
    }
}
