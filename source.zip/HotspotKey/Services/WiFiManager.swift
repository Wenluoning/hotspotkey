//
//  WiFiManager.swift
//  读取当前网络 + 发起连接
//
//  iOS 的真实限制（务必了解）：
//  1. 系统不开放 WiFi 扫描接口，App 无法列出"附近有哪些热点"，
//     只能列出自己库里认为存在的热点，再尝试连接验证。
//  2. iOS 13 起读取当前 SSID 必须先拿到定位权限（系统把它归为位置信息）。
//  3. 连接需要 NEHotspotConfiguration，属于 Hotspot Configuration capability，
//     需要真机 + 带该 entitlement 的签名。
//

import Foundation
import NetworkExtension
import CoreLocation
import Combine

@MainActor
final class WiFiManager: NSObject, ObservableObject {
    @Published private(set) var currentSSID: String?
    @Published private(set) var currentBSSID: String?
    @Published private(set) var authorization: CLAuthorizationStatus = .notDetermined
    @Published private(set) var isConnecting = false
    @Published var lastError: String?
    @Published var lastMessage: String?

    /// NEHotspotConfigurationError.alreadyAssociated 的 rawValue，用数字避免成员名变更
    private static let alreadyAssociated = 10

    private let locationManager = CLLocationManager()

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        authorization = locationManager.authorizationStatus
    }

    // MARK: - 权限

    func requestPermission() {
        if authorization == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        }
    }

    var hasLocationPermission: Bool {
        authorization == .authorizedWhenInUse || authorization == .authorizedAlways
    }

    // MARK: - 读取当前网络

    func refreshCurrentNetwork() {
        guard hasLocationPermission else {
            currentSSID = nil
            currentBSSID = nil
            return
        }
        NEHotspotNetwork.fetchCurrent { [weak self] network in
            Task { @MainActor in
                guard let self else { return }
                self.currentSSID = network?.ssid
                self.currentBSSID = network?.bssid
            }
        }
    }

    func isConnected(to hotspot: Hotspot) -> Bool {
        guard let current = currentSSID else { return false }
        return current.caseInsensitiveCompare(hotspot.ssid) == .orderedSame
    }

    // MARK: - 连接

    func connect(to hotspot: Hotspot, joinOnce: Bool = false) async -> Bool {
        let password = hotspot.security == .open ? nil : hotspot.password
        return await join(ssid: hotspot.ssid,
                          password: password,
                          isWEP: hotspot.security == .wep,
                          joinOnce: joinOnce)
    }

    func join(ssid: String, password: String?, isWEP: Bool, joinOnce: Bool = false) async -> Bool {
        isConnecting = true
        lastError = nil
        lastMessage = nil
        defer { isConnecting = false }

        let config: NEHotspotConfiguration
        if let password, !password.isEmpty {
            config = NEHotspotConfiguration(ssid: ssid, passphrase: password, isWEP: isWEP)
        } else {
            config = NEHotspotConfiguration(ssid: ssid)
        }
        config.joinOnce = joinOnce
        config.hidden = false

        let result: Result<Void, Error> = await withCheckedContinuation { continuation in
            NEHotspotConfigurationManager.shared.apply(config) { error in
                if let error = error as NSError?,
                   error.domain == NEHotspotConfigurationErrorDomain,
                   error.code == Self.alreadyAssociated {
                    continuation.resume(returning: .success(()))
                    return
                }
                if let error {
                    continuation.resume(returning: .failure(error))
                } else {
                    continuation.resume(returning: .success(()))
                }
            }
        }

        switch result {
        case .success:
            currentSSID = ssid
            lastMessage = "已加入 “\(ssid)”"
            return true
        case .failure(let error):
            lastError = Self.describe(error)
            return false
        }
    }

    func forget(ssid: String) {
        NEHotspotConfigurationManager.shared.removeConfiguration(forSSID: ssid)
        if currentSSID == ssid { currentSSID = nil; currentBSSID = nil }
    }

    // MARK: - 错误文案

    /// 把错误码翻成人话。
    /// 用 rawValue 数字而不是枚举成员名：这些 Code 值在 SDK 里是稳定的，
    /// 而成员名可能随 SDK 版本调整（比如 invalidHS20Domain 在某些版本里就不可用）。
    private static func describe(_ error: Error) -> String {
        let ns = error as NSError
        guard ns.domain == NEHotspotConfigurationErrorDomain else {
            return ns.localizedDescription
        }
        switch ns.code {
        case 0:      return "配置参数无效"
        case 1:      return "SSID 无效"
        case 2:      return "密码格式不对（WPA 需 8–63 位）"
        case 3:      return "WEP 密钥格式不对（5/13 位或 10/26 位十六进制）"
        case 4:      return "企业级认证参数无效"
        case 5, 6:   return "Hotspot 2.0 参数或域名无效"
        case 7:      return "用户取消了连接请求"
        case 8:      return "请求仍在处理中"
        case 9:      return "系统拒绝了该配置"
        case 10:     return "已经连上这个网络了"
        case 11:     return "App 需在前台才能发起连接"
        case 12:     return "系统内部错误"
        default:     return ns.localizedDescription
        }
    }
}

// MARK: - CLLocationManagerDelegate

extension WiFiManager: CLLocationManagerDelegate {
    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        Task { @MainActor in
            self.authorization = status
            if status == .authorizedWhenInUse || status == .authorizedAlways {
                self.refreshCurrentNetwork()
            }
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let message = error.localizedDescription
        Task { @MainActor in
            self.lastError = "定位失败：\(message)"
        }
    }
}
