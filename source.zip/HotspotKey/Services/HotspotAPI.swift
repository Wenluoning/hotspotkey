//
//  HotspotAPI.swift
//  在线共享库客户端
//
//  这是一个「可插拔」的网络层：配置了 baseURL 就走远端，
//  没配置就完全离线，UI 会显示未启用。
//
//  约定的接口（换成自己的后端时按这个实现即可）：
//    GET  {base}/v1/hotspots?limit=50      → { "items": [RemoteHotspot] }
//    GET  {base}/v1/hotspots?q=ssid        → 同上，按 SSID 模糊搜
//    POST {base}/v1/hotspots               ← RemoteHotspot，201 表示成功
//    POST {base}/v1/reports                ← { "ssid": "...", "success": true }
//

import Foundation

/// 远端条目（不含 isMine，本地概念）
struct RemoteHotspot: Codable {
    var ssid: String
    var bssid: String?
    var password: String
    var security: String
    var sharedBy: String
    var sharedAt: Date
    var successCount: Int
    var failCount: Int
    var note: String?

    enum CodingKeys: String, CodingKey {
        case ssid, bssid, password, security, sharedBy, sharedAt, successCount, failCount, note
    }

    func toHotspot() -> Hotspot {
        Hotspot(ssid: ssid,
                bssid: bssid,
                password: password,
                security: Security(rawValue: security) ?? .wpa2,
                sharedBy: sharedBy,
                sharedAt: sharedAt,
                successCount: successCount,
                failCount: failCount,
                note: note,
                isMine: false)
    }
}

struct HotspotListResponse: Codable {
    var items: [RemoteHotspot]
}

/// 上报连接结果
struct ReportPayload: Codable {
    var ssid: String
    var success: Bool
}

enum APIError: LocalizedError {
    case notConfigured
    case badStatus(Int)
    case decoding(String)
    case transport(String)

    var errorDescription: String? {
        switch self {
        case .notConfigured:      return "还没有配置在线库地址"
        case .badStatus(let code): return "服务端返回 \(code)"
        case .decoding(let text):  return "返回数据解析失败：\(text)"
        case .transport(let text): return "网络错误：\(text)"
        }
    }
}

final class HotspotAPI {
    /// 存在 UserDefaults，设置页可改
    static let baseURLKey = "hotspot.api.baseURL"

    static var configuredBaseURL: URL? {
        guard let raw = UserDefaults.standard.string(forKey: baseURLKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines),
              !raw.isEmpty,
              let url = URL(string: raw),
              url.scheme == "https" || url.scheme == "http" else {
            return nil
        }
        return url
    }

    static func setBaseURL(_ raw: String) {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            UserDefaults.standard.removeObject(forKey: baseURLKey)
        } else {
            UserDefaults.standard.set(trimmed, forKey: baseURLKey)
        }
    }

    private let session: URLSession
    private let decoder: JSONDecoder
    private let encoder: JSONEncoder

    init() {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.waitsForConnectivity = false
        config.httpAdditionalHeaders = ["Accept": "application/json"]
        session = URLSession(configuration: config)

        decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
    }

    private func endpoint(_ path: String, query: [URLQueryItem] = []) throws -> URL {
        guard let base = Self.configuredBaseURL else { throw APIError.notConfigured }
        var components = URLComponents(url: base.appendingPathComponent(path),
                                       resolvingAgainstBaseURL: false)
        if !query.isEmpty { components?.queryItems = query }
        guard let url = components?.url else { throw APIError.notConfigured }
        return url
    }

    // MARK: - 读

    func fetchHotspots(keyword: String? = nil, limit: Int = 50) async throws -> [Hotspot] {
        var query = [URLQueryItem(name: "limit", value: String(limit))]
        if let keyword, !keyword.isEmpty {
            query.append(URLQueryItem(name: "q", value: keyword))
        }
        var request = URLRequest(url: try endpoint("v1/hotspots", query: query))
        request.httpMethod = "GET"

        let (data, response) = try await send(request)
        try validate(response)
        do {
            let decoded = try decoder.decode(HotspotListResponse.self, from: data)
            return decoded.items.map { $0.toHotspot() }
        } catch {
            throw APIError.decoding(error.localizedDescription)
        }
    }

    // MARK: - 写

    func share(_ hotspot: Hotspot) async throws {
        var request = URLRequest(url: try endpoint("v1/hotspots"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let payload = RemoteHotspot(ssid: hotspot.ssid,
                                    bssid: hotspot.bssid,
                                    password: hotspot.password,
                                    security: hotspot.security.rawValue,
                                    sharedBy: hotspot.sharedBy,
                                    sharedAt: hotspot.sharedAt,
                                    successCount: hotspot.successCount,
                                    failCount: hotspot.failCount,
                                    note: hotspot.note)
        request.httpBody = try encoder.encode(payload)

        let (_, response) = try await send(request)
        try validate(response)
    }

    func report(ssid: String, success: Bool) async throws {
        var request = URLRequest(url: try endpoint("v1/reports"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(ReportPayload(ssid: ssid, success: success))

        let (_, response) = try await send(request)
        try validate(response)
    }

    // MARK: - 底层

    private func send(_ request: URLRequest) async throws -> (Data, URLResponse) {
        do {
            return try await session.data(for: request)
        } catch {
            throw APIError.transport(error.localizedDescription)
        }
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.badStatus(http.statusCode)
        }
    }
}
