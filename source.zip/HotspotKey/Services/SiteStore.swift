//
//  SiteStore.swift
//  到访地点：记录、去重合并、LRU 持久化
//
//  用途：把「曾经在哪些地方自动蹭过网」记下来，
//  下次到同一地点可以直接复用结论，也用来注册圆形地理围栏。
//

import Foundation
import CoreLocation

struct Site: Identifiable, Codable, Hashable {
    var id: UUID
    var name: String
    var latitude: Double
    var longitude: Double
    /// 围栏半径（米）
    var radius: Double
    var firstVisitedAt: Date
    var lastVisitedAt: Date
    /// 最近一次自动试连的时间
    var lastCrackedAt: Date?
    /// 在该地点试连命中的次数
    var crackHits: Int
    /// 到访次数
    var visits: Int

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }

    var shortName: String {
        name.isEmpty ? String(format: "%.4f, %.4f", latitude, longitude) : name
    }
}

@MainActor
final class SiteStore: ObservableObject {
    @Published private(set) var sites: [Site] = []

    /// 300 米内算「同一个地方」，避免每次 GPS 抖动都新建一条
    private let mergeRadius: CLLocationDistance = 300
    /// 最多保留多少条，超出按最近到访丢弃
    private let maxSites = 30
    /// iOS 最多允许 20 个圆形围栏，给系统留 1 个余量
    static let maxMonitored = 19

    private var didBootstrap = false
    private var fileURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("HotspotKey", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir.appendingPathComponent("sites.json")
    }

    // MARK: - 生命周期

    func bootstrap() {
        guard !didBootstrap else { return }
        didBootstrap = true
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? decoder.decode([Site].self, from: data) else { return }
        sites = decoded
    }

    // MARK: - 记录

    /// 记录一次到访；300 米内已有地点则合并，返回最终条目
    @discardableResult
    func record(latitude: Double, longitude: Double, name: String = "", at date: Date = Date()) -> Site {
        let incoming = CLLocation(latitude: latitude, longitude: longitude)

        if let index = sites.firstIndex(where: { site in
            CLLocation(latitude: site.latitude, longitude: site.longitude)
                .distance(from: incoming) <= mergeRadius
        }) {
            sites[index].lastVisitedAt = date
            sites[index].visits += 1
            if sites[index].name.isEmpty, !name.isEmpty {
                sites[index].name = name
            }
            let updated = sites[index]
            sortAndPrune()
            save()
            return updated
        }

        let site = Site(id: UUID(),
                        name: name,
                        latitude: latitude,
                        longitude: longitude,
                        radius: 900,
                        firstVisitedAt: date,
                        lastVisitedAt: date,
                        lastCrackedAt: nil,
                        crackHits: 0,
                        visits: 1)
        sites.append(site)
        sortAndPrune()
        save()
        return site
    }

    func markCracked(_ site: Site, hits: Int) {
        guard let index = sites.firstIndex(where: { $0.id == site.id }) else { return }
        sites[index].lastCrackedAt = Date()
        if hits > 0 { sites[index].crackHits += hits }
        save()
    }

    func rename(_ site: Site, to name: String) {
        guard let index = sites.firstIndex(where: { $0.id == site.id }) else { return }
        sites[index].name = name
        save()
    }

    func remove(_ site: Site) {
        sites.removeAll { $0.id == site.id }
        save()
    }

    func removeAll() {
        sites.removeAll()
        save()
    }

    // MARK: - 查询

    /// 最近到访，用于注册围栏
    var monitored: [Site] {
        Array(sites.sorted { $0.lastVisitedAt > $1.lastVisitedAt }.prefix(Self.maxMonitored))
    }

    func recent(_ limit: Int = 5) -> [Site] {
        Array(sites.sorted { $0.lastVisitedAt > $1.lastVisitedAt }.prefix(limit))
    }

    func contains(latitude: Double, longitude: Double) -> Site? {
        let point = CLLocation(latitude: latitude, longitude: longitude)
        return sites.first { site in
            CLLocation(latitude: site.latitude, longitude: site.longitude)
                .distance(from: point) <= mergeRadius
        }
    }

    // MARK: - 私有

    private func sortAndPrune() {
        sites.sort { $0.lastVisitedAt > $1.lastVisitedAt }
        if sites.count > maxSites {
            sites = Array(sites.prefix(maxSites))
        }
    }

    private var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }

    private var encoder: JSONEncoder {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }

    private func save() {
        guard let data = try? encoder.encode(sites) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
