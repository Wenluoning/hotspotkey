//
//  Hotspot.swift
//  热点条目模型
//

import Foundation

/// WiFi 加密类型
enum Security: String, Codable, CaseIterable, Identifiable {
    case wpa2, wpa3, wep, open

    var id: String { rawValue }

    var label: String {
        switch self {
        case .wpa2: return "WPA2"
        case .wpa3: return "WPA3"
        case .wep:  return "WEP"
        case .open: return "开放网络"
        }
    }

    var symbol: String {
        switch self {
        case .wpa2: return "lock.fill"
        case .wpa3: return "lock.shield.fill"
        case .wep:  return "lock.open.fill"
        case .open: return "wifi"
        }
    }

    /// 密钥是否符合该加密类型的基本长度要求
    func validate(_ password: String) -> Bool {
        switch self {
        case .open: return true
        case .wep:  return password.count == 5 || password.count == 13
                    || password.count == 10 || password.count == 26
        case .wpa2, .wpa3: return (8...63).contains(password.count)
        }
    }
}

/// 一个共享热点
struct Hotspot: Identifiable, Codable, Hashable {
    var ssid: String
    var bssid: String?
    /// 已解密的明文密码；落盘时由 HotspotStore 加密
    var password: String
    var security: Security
    var sharedBy: String
    var sharedAt: Date
    var successCount: Int
    var failCount: Int
    var note: String?
    var isMine: Bool

    var id: String { "\(ssid)|\(bssid ?? "-")" }

    init(ssid: String,
         bssid: String? = nil,
         password: String,
         security: Security = .wpa2,
         sharedBy: String = "我",
         sharedAt: Date = Date(),
         successCount: Int = 0,
         failCount: Int = 0,
         note: String? = nil,
         isMine: Bool = false) {
        self.ssid = ssid
        self.bssid = bssid
        self.password = password
        self.security = security
        self.sharedBy = sharedBy
        self.sharedAt = sharedAt
        self.successCount = successCount
        self.failCount = failCount
        self.note = note
        self.isMine = isMine
    }

    /// 成功率，无样本时给 0.5 的中位数先验
    var successRate: Double {
        let total = successCount + failCount
        guard total > 0 else { return 0.5 }
        // Wilson 下界，样本少时不虚高
        let z = 1.96
        let p = Double(successCount) / Double(total)
        let n = Double(total)
        let denom = 1 + z * z / n
        let centre = p + z * z / (2 * n)
        let margin = z * (p * (1 - p) / n + z * z / (4 * n * n)).squareRoot()
        return max(0, min(1, (centre - margin) / denom))
    }

    /// 0…1 的热度，用于列表排序与着色
    var heat: Double {
        let recent = Date().timeIntervalSince(sharedAt)
        let freshness = max(0, 1 - recent / (60 * 60 * 24 * 180)) // 半年线性衰减
        return min(1, successRate * 0.75 + freshness * 0.25)
    }

    var heatLabel: String {
        switch heat {
        case 0.72...: return "高成功率"
        case 0.45..<0.72: return "可用"
        default: return "待验证"
        }
    }

    /// 列表里展示的脱敏密码
    var maskedPassword: String {
        guard !password.isEmpty else { return "—" }
        if password.count <= 2 { return String(repeating: "•", count: password.count) }
        return String(password.prefix(1))
            + String(repeating: "•", count: max(3, password.count - 2))
            + String(password.suffix(1))
    }

    var bssidShort: String {
        guard let bssid, !bssid.isEmpty else { return "未知 BSSID" }
        return bssid.uppercased()
    }
}
