//
//  SeedData.swift
//  内置示例库 —— 全部为虚构 SSID 与占位密码，仅用于演示列表与排序逻辑
//

import Foundation

enum SeedData {
    static func make() -> [Hotspot] {
        let now = Date()
        func ago(_ days: Double) -> Date { now.addingTimeInterval(-days * 86_400) }

        return [
            Hotspot(ssid: "Starbucks-Guest", bssid: "0C:8D:DB:1A:22:01", password: "wifi12345",
                    security: .wpa2, sharedBy: "阿泽", sharedAt: ago(2), successCount: 184, failCount: 9,
                    note: "门店通用，晚高峰偶尔掉线"),
            Hotspot(ssid: "CMCC-Free", bssid: "34:6B:D3:9C:10:2A", password: "cmcc2024",
                    security: .wpa2, sharedBy: "小林", sharedAt: ago(5), successCount: 96, failCount: 21,
                    note: "需要网页登录，密码只是第一步"),
            Hotspot(ssid: "ChinaNet-8fA2", bssid: "AC:85:3D:77:8F:A2", password: "8fa2wifi88",
                    security: .wpa2, sharedBy: "老王", sharedAt: ago(11), successCount: 42, failCount: 3),
            Hotspot(ssid: "McDonalds_Free_WiFi", bssid: "D8:9E:F3:44:11:B7", password: "",
                    security: .open, sharedBy: "路人甲", sharedAt: ago(1), successCount: 311, failCount: 2,
                    note: "开放网络，无密码"),
            Hotspot(ssid: "TP-LINK_5G_9F2C", bssid: "50:64:2B:9F:2C:01", password: "tplink9f2c",
                    security: .wpa2, sharedBy: "租客群", sharedAt: ago(23), successCount: 27, failCount: 14),
            Hotspot(ssid: "Library-Reader", bssid: "E4:95:6E:0A:31:5C", password: "reader2023",
                    security: .wpa3, sharedBy: "学生党", sharedAt: ago(34), successCount: 63, failCount: 5),
            Hotspot(ssid: "HUAWEI-A1B2", bssid: "C8:94:BB:A1:B2:00", password: "huawei8888",
                    security: .wpa2, sharedBy: "搬家师傅", sharedAt: ago(48), successCount: 12, failCount: 11),
            Hotspot(ssid: "Airport_Free_WiFi", bssid: "0A:1B:2C:3D:4E:5F", password: "",
                    security: .open, sharedBy: "民航服务", sharedAt: ago(3), successCount: 205, failCount: 6,
                    note: "航站楼限时 2 小时"),
            Hotspot(ssid: "Home-2.4G", bssid: "A4:2B:B0:12:34:56", password: "home2024ok",
                    security: .wpa2, sharedBy: "邻居阿姨", sharedAt: ago(72), successCount: 8, failCount: 9),
            Hotspot(ssid: "Hotel_Hilton_Lobby", bssid: "F0:9F:C2:88:76:54", password: "hilton-guest",
                    security: .wpa2, sharedBy: "出差狗", sharedAt: ago(9), successCount: 54, failCount: 7,
                    note: "房卡号即密码，前台可问"),
            Hotspot(ssid: "KFC-Free-WiFi", bssid: "6C:19:C0:AA:BB:CC", password: "",
                    security: .open, sharedBy: "吃货", sharedAt: ago(6), successCount: 143, failCount: 4),
            Hotspot(ssid: "Old_Router_WEP", bssid: "00:1D:0F:AA:11:22", password: "abcde",
                    security: .wep, sharedBy: "老设备", sharedAt: ago(140), successCount: 2, failCount: 7,
                    note: "WEP 已极不安全，仅老路由在用")
        ]
    }
}
