# 钥匙通 HotspotKey

iOS 上的「WiFi 万能钥匙」形态：**用户不知道密码，点一下就连上**。
共享密码库 + 自动试连引擎 + 二维码收发，SwiftUI 编写，iOS 16+。

```
HotspotKey/
├── HotspotKey.xcodeproj/          # 已生成，双击可开
├── HotspotKey/
│   ├── App/HotspotKeyApp.swift
│   ├── Models/{Hotspot,SeedData}.swift
│   ├── Services/
│   │   ├── AutoJoinEngine.swift   # ★ 一键蹭网：批量试库、排序、超时、预置
│   │   ├── RegionWatcher.swift    # ★ 地点触发：CLVisit + 地理围栏 + 通知
│   │   ├── SiteStore.swift        # 到访地点记录（300m 合并、LRU）
│   │   ├── WiFiManager.swift      # 当前网络 + NEHotspotConfiguration 连接
│   │   ├── HotspotStore.swift     # 本地库：加载/保存/检索/合并/反馈
│   │   ├── HotspotAPI.swift       # 在线库客户端（可插拔）
│   │   ├── CryptoBox.swift        # AES-GCM + Keychain
│   │   └── QRCode.swift           # WIFI: 二维码编解码
│   ├── Views/
│   │   ├── RootView / HomeView（含一键蹭网卡片）/ LibraryView
│   │   ├── HotspotDetailView / ShareView / ScannerView
│   │   ├── SettingsView（预置网络、静默模式、在线库）
│   │   └── Components.swift
│   ├── Support/{Info.plist, HotspotKey.entitlements, HotspotKey-basic.entitlements}
│   └── Resources/Assets.xcassets
├── scripts/{gen_pbxproj,gen_icon,make_ipa,selfcheck}.py + build_ipa.sh
├── .github/workflows/build-ipa.yml
└── dist/
```

---

## 一、先讲清机制：这是「试库」，不是破解

用户视角是「不知道密码也能连」。实现上是这样的链路：

```
密码库里 N 条候选
      ↓ 按命中率排序
逐条提交 NEHotspotConfiguration(ssid, password)
      ↓ 系统返回成功 / 失败
成功的那条 = 附近存在 + 密码正确 → iOS 写入「已知网络」
```

密码本身来自共享库（本地录入、扫码、在线库同步），系统只负责验证。这就是所有「万能钥匙」类产品的真实内核。

**iOS 上不存在的那条路**（这一点决定了产品形态，别指望绕过）：

| 真破解需要 | iOS 的情况 |
|---|---|
| 网卡进入 monitor mode 抓 4-way 握手包 | 没有这个能力，网卡归系统独占 |
| 原始 socket 发送/接收管理帧（deauth、注入） | 应用层拿不到 raw socket |
| 本地跑 hashcat 爆破 PSK | 无 GPU 计算接口，且先得抓到握手包 |
| WPS PIN 爆破 | 无 WPS 相关接口 |

所以「不问密码、不问二维码，凭空拿到 WPA2 密钥」在 iPhone 上没有技术入口。能做的是把**命中率做到足够高、过程做到足够无感**，这也是本工程的实现重点。

安卓之所以看起来更「流氓」，是因为 root 后能读 `/data/misc/wifi/wpa_supplicant.conf` 直接偷本机存过的密码，并有 monitor mode 抓包。iOS 两条都封死了。

---

## 二、一键蹭网怎么工作

`AutoJoinEngine` 的四个设计点：

**1. 排序决定命中速度**

```
开放网络（nopass，无需密码） → 历史失败次数少 → 热度高（Wilson 成功率 + 新鲜度）
```

连续失败 3 次的条目直接踢出候选，不再浪费时间。

**2. 串行 + 超时**

系统拒绝并发 `apply`，必须一条一条来。单条 9 秒超时（周围没这个网络时系统响应可能极慢），两次之间留 700ms 间隔。命中平均 2–3 条就能连上，最坏情况按条数线性增长。

**3. 失败也要记账**

每条结果写回 `successCount / failCount`，下次排序自动把「屡试不中」的沉底——库越用越准。

**4. 先补库再试**

配了在线库的会先 `GET /v1/hotspots?limit=200`（4 秒超时），把云端候选合进本地再开始试。库覆盖率直接决定命中率。

**界面**：首页大卡片一个按钮 → 进度条 + `正在试探 Starbucks-Guest [3/24]` + 最近三条日志 → 命中显示「已连接，密码已写入系统」。

**静默模式**（`autocrack.silent`）：连上后只显示「已连接」，不暴露网络名与密码。

---

## 三、预置：让系统自己连，不用开 App

「设置 → 自动连网 → 把库里网络预置进系统」会逐条 `apply`（`joinOnce = false`），成功的都会被 iOS 记进已知网络列表。之后用户走到覆盖范围内，手机会自动连——连 App 都不用打开。

这是 iPhone 上最接近「全自动蹭网」的效果：**用一次预置，换长期自动**。代价是预置过程中会不断切换网络，当前连接会中断，所以做了二次确认。

---

## 四、地点自动连网（走到商圈就能连）

三层机制拼出「无人值守」：

```
CLVisit 自动发现到访（不用预先设点）
        ↓
记入 SiteStore，300 米内合并成同一地点，注册圆形围栏（最近 19 个）
        ↓
到访事件 → 本地通知 + 前台补跑一轮试连 → 命中写进系统已知网络
        ↓
下次到同一地点：iOS 自己就连上了，App 都不用开
```

**一条绕不过去的约束**：`NEHotspotConfigurationManager.apply` 只接受前台调用，后台调用返回 `applicationIsNotInForeground`。所以实现上分了两条：

- **后台到访**：只记账 + 发本地通知（「到了新地方 · 点开自动连网」）
- **回到前台**：`RootView` 用 `scenePhase` 检测到 `pendingAutoCrack`，自动补跑一轮试连
- **第二次到访**：网络已经在系统已知列表里，iOS 直接连，完全无人值守

需要的权限：定位「始终允许」+ 通知。`Info.plist` 已声明 `UIBackgroundModes = location`（否则设置 `allowsBackgroundLocationUpdates` 会抛异常）。

界面：设置 → 地点自动连网 → 开关 + 最近 5 个地点（到访次数 / 命中次数）+ 清空。

## 五、出 ipa

### 有 Mac + Xcode

```bash
cd HotspotKey
bash scripts/build_ipa.sh --unsigned          # 未签名 ipa，Sideloadly/AltStore 自签
export DEVELOPMENT_TEAM=ABCDE12345
bash scripts/build_ipa.sh                     # 有证书直接出可装 ipa
bash scripts/build_ipa.sh --entitlements full # 真机连接需完整 entitlement
```

### 没 Mac

`.github/workflows/build-ipa.yml`：推 GitHub → Actions 手动跑 → 未签名 ipa 作为 artifact 下载（`signed-ipa` job 配四个 Secret 后可出签名包）。或用云 Mac 跑上面第一条。

> 生成环境是一台 iPhone（DSH 应用内 shell），**没有 swiftc / xcodebuild / codesign**，所以打包链路已在本机跑通并产出结构样张 `dist/HotspotKey-skeleton.ipa`（plist 可解析、zip 完好、条目全在 `Payload/` 下）。样张不含真实可执行文件，装不上手机，属预期。

---

## 六、真机连接的前提：entitlement

1. **付费开发者账号**（免费账号的证书不带该权限）
2. Developer Portal → App ID 开启：
   - `Hotspot Configuration` → `com.apple.developer.networking.HotspotConfiguration`
   - `Access WiFi Information` → `com.apple.developer.networking.wifi-info`

```bash
bash scripts/build_ipa.sh --entitlements full
```

默认 `HotspotKey-basic.entitlements`（空字典）：任何账号都能签、能装、能看界面，但试连会被系统拒绝——引擎检测到连续两次「系统拒绝」会自动停下并提示，不会白耗电。

---

## 七、其余功能

- **附近**：当前网络卡片（SSID/BSSID）、热度排序推荐、统计、下拉刷新
- **密码库**：搜索、三种排序、左滑删除/复制、掩码与明文切换
- **详情**：一键连接、一次性连接、成功失败上报、忘记网络、生成分享二维码
- **共享**：手动录入 + 格式校验、扫二维码自动填入
- **二维码**：`WIFI:T:WPA;S:网络名;P:密码;H:false;;` 标准格式，系统相机可直接识别
- **地点**：到访自动记录、地理围栏提醒、到新地点自动试连
- **存储**：密码 AES-GCM 加密落盘、主密钥进 Keychain、默认不联网

---

## 八、在线库接口

设置页填地址即启用；留空完全离线。

```
GET  {base}/v1/hotspots?limit=50    → { "items": [ ... ] }
GET  {base}/v1/hotspots?q=ssid
POST {base}/v1/hotspots             ← 单条热点，201 成功
POST {base}/v1/reports              ← { "ssid": "...", "success": true }
```

最小可用后端（FastAPI）：

```python
from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime, timezone

app = FastAPI()
db: dict[str, dict] = {}

class Item(BaseModel):
    ssid: str; bssid: str | None = None; password: str; security: str = "wpa2"
    sharedBy: str = "匿名"; sharedAt: datetime | None = None
    successCount: int = 0; failCount: int = 0; note: str | None = None

@app.get("/v1/hotspots")
def list_hotspots(limit: int = 50, q: str | None = None):
    items = list(db.values())
    if q: items = [i for i in items if q.lower() in i["ssid"].lower()]
    return {"items": items[:limit]}

@app.post("/v1/hotspots", status_code=201)
def share(item: Item):
    data = item.model_dump()
    data["sharedAt"] = data["sharedAt"] or datetime.now(timezone.utc)
    db[data["ssid"]] = data
    return {"ok": True}

@app.post("/v1/reports")
def report(ssid: str, success: bool):
    if ssid in db:
        db[ssid]["successCount" if success else "failCount"] += 1
    return {"ok": True}
```

线上还要补：账号体系、提交限频、密码不进日志、下线通道。

---

## 九、脚本

| 脚本 | 用途 | 环境 |
|---|---|---|
| `gen_pbxproj.py` | 生成 `project.pbxproj`（UUID 由路径 md5 派生） | 任意 python3 |
| `gen_icon.py` | SDF 画 1024 图标，纯 zlib 手写 PNG | 任意 python3 |
| `build_ipa.sh` | archive / export / 未签名打包 | macOS + Xcode |
| `make_ipa.py` | `.app` → ipa，自带 Payload 校验 | 任意 python3 |
| `selfcheck.py` | 括号、Sources 完整性、plist/JSON、图标引用 | 任意 python3 |

---

## 十、命中率能到多少

取决于三件事，与代码无关：

1. **库覆盖率**——本地示例 12 条只在演示里"命中"；真实价值来自在线库体量
2. **地推质量**——同一商圈反复有人共享，同一个 SSID 的密码一致率才高（连锁店常见，家庭网络几乎每次都不同）
3. **位置**——试连只能验证"周围有没有这个网络"，验证不了"密码是不是这家店的"

工程上能做的都做了：排序、跳过、失败记账、云端补库、批量预置。剩下的靠数据。

---

## 十一、合规

密码库是他人凭证。上架前至少做到：只允许共享自己有权使用的网络、说明数据来源、提供删除通道。技术跑通与能否上架是两件事。
